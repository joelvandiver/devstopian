import { useQuery } from "@tanstack/react-query";
import type { Model } from "../ds/model";

async function getJSON<T>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${res.status} ${url}`);
  return res.json() as Promise<T>;
}

export function useModel() {
  return useQuery({ queryKey: ["model"], queryFn: () => getJSON<Model>("/api/model") });
}

export function useExport(format: string) {
  return useQuery({
    queryKey: ["export", format],
    queryFn: async () => {
      const res = await fetch(`/api/model/export/${format}`);
      if (!res.ok) throw new Error("export failed");
      return res.text();
    },
  });
}
