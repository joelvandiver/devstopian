import { useState } from "react";
import { appHref, PipelineBreadcrumb, useCopy } from "../ds";
import { checksum, counts, completeness, FORMATS } from "../ds/model";
import { useExport, useModel } from "./api";

function fmtBytes(b: number): string {
  if (b < 1024) return b + " B";
  const u = ["KB", "MB"];
  let i = -1;
  do {
    b /= 1024;
    i++;
  } while (b >= 1024 && i < u.length - 1);
  return b.toFixed(1) + " " + u[i];
}

export function DownloadView() {
  const { data: model } = useModel();
  const [fmtId, setFmtId] = useState<string>("json");
  const fmt = FORMATS.find((f) => f.id === fmtId)!;
  const { data: text = "" } = useExport(fmtId);
  const { copied, copy } = useCopy();

  if (!model) return <main className="mx-auto max-w-[1480px] px-4 py-10 text-sm text-fg-muted">Loading model…</main>;

  const c = counts(model);
  const pct = completeness(model);
  const open = c.review + c.conflict + c.gap + c.awaiting;
  const draft = /draft/.test(model.meta.version);
  const byteSize = new Blob([text]).size;

  function download() {
    const blob = new Blob([text], { type: fmt.mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${model!.meta.slug}.${fmt.ext}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  return (
    <main className="mx-auto max-w-[1480px] px-4 py-5">
      <PipelineBreadcrumb active="download" />

      <div className="mb-4 flex flex-wrap items-end justify-between gap-4 border-b border-border pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-fg">{model.meta.name}</h1>
            <span
              className={`inline-flex items-center rounded-sm border px-1.5 py-0.5 font-mono text-2xs ${
                draft
                  ? "border-warning-border bg-warning-bg text-warning"
                  : "border-success-border bg-success-bg text-success"
              }`}
            >
              v{model.meta.version}
            </span>
          </div>
          <p className="mt-1 text-sm text-fg-muted">
            The reviewed model, assembled from your uploaded files and the agent pipeline — ready to export.
          </p>
        </div>
        <button
          onClick={download}
          className="inline-flex items-center gap-2 rounded-md bg-accent px-4 py-2 text-sm font-medium text-fg-on-accent hover:bg-accent-hover"
        >
          <span>↓</span> Download <span className="font-mono">{fmt.label}</span>
        </button>
      </div>

      {open > 0 && (
        <div className="mb-4 flex items-start gap-3 rounded-md border border-warning-border bg-warning-bg px-3 py-2.5 text-warning">
          <span className="mt-0.5 grid size-4 shrink-0 place-items-center rounded-full border border-warning text-2xs font-bold">!</span>
          <div className="min-w-0">
            <p className="text-sm font-semibold">{open} fields are still unconfirmed</p>
            <p className="text-xs text-warning/80">
              The model is exportable, but gaps and pending surveys are marked{" "}
              <span className="font-mono">null</span>. Resolve them in promotion for a complete export.
            </p>
          </div>
          <a
            href={appHref("promote")}
            className="ml-auto shrink-0 rounded-md border border-warning/40 px-2.5 py-1 text-xs font-medium hover:bg-warning/10"
          >
            Back to promote
          </a>
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        {/* PREVIEW */}
        <section className="flex min-h-0 flex-col rounded-lg border border-border bg-surface-raised shadow-sm">
          <div className="flex flex-wrap items-center gap-2 border-b border-border px-3 py-2">
            <div className="inline-flex items-center gap-0.5 rounded-md border border-border bg-surface p-0.5 text-xs">
              {FORMATS.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFmtId(f.id)}
                  aria-pressed={f.id === fmtId}
                  className={`rounded px-2.5 py-1 font-medium ${f.id === fmtId ? "bg-accent text-fg-on-accent" : "text-fg-muted hover:text-fg"}`}
                >
                  {f.label}
                </button>
              ))}
            </div>
            <span className="font-mono text-2xs text-fg-subtle">{model.meta.slug}.{fmt.ext}</span>
            <div className="ml-auto flex items-center gap-2">
              <span className="font-mono text-2xs text-fg-subtle">{fmtBytes(byteSize)}</span>
              <button
                onClick={() => copy(text)}
                className="rounded-md border border-border bg-surface px-2.5 py-1 text-xs font-medium text-fg-muted hover:bg-hover hover:text-fg"
              >
                {copied ? "Copied" : "Copy"}
              </button>
            </div>
          </div>
          <pre className="max-h-[560px] overflow-auto bg-surface-inset px-3 py-3 font-mono text-2xs leading-relaxed text-fg-muted">
            {text}
          </pre>
        </section>

        {/* SIDEBAR */}
        <aside className="space-y-4">
          {/* SEAL */}
          <div className="rounded-lg border border-border bg-surface-raised p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <div
                className="grid size-16 shrink-0 place-items-center rounded-full"
                style={{ background: `conic-gradient(var(--color-accent) ${pct}%, var(--color-surface-inset) 0)` }}
              >
                <div className="grid size-12 place-items-center rounded-full bg-surface-raised">
                  <span className="text-sm font-semibold tabular-nums text-fg">{pct}%</span>
                </div>
              </div>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-fg">Completeness</p>
                <p className="text-xs text-fg-muted">{c.confirmed} of {c.total} fields confirmed</p>
                <p className="mt-1 font-mono text-2xs text-fg-subtle">
                  checksum <span className="text-fg-muted">{checksum(model)}</span>
                </p>
              </div>
            </div>
            <dl className="mt-3 grid grid-cols-2 gap-px overflow-hidden rounded-md border border-border bg-border text-center">
              {[
                ["Entities", String(model.entities.length)],
                ["Fields", String(c.total)],
                ["Sources", String(model.meta.sourceFiles.length)],
                ["Generated", new Date(model.meta.generated).toLocaleDateString("en-US", { month: "short", day: "numeric" })],
              ].map(([label, value]) => (
                <div key={label} className="bg-surface-raised px-2 py-2">
                  <dt className="text-2xs font-mono uppercase tracking-wide text-fg-subtle">{label}</dt>
                  <dd className="mt-0.5 text-sm font-semibold tabular-nums text-fg">{value}</dd>
                </div>
              ))}
            </dl>
          </div>

          {/* ENTITY SUMMARY */}
          <div className="rounded-lg border border-border bg-surface-raised shadow-sm">
            <div className="border-b border-border px-3 py-2">
              <h2 className="text-sm font-semibold text-fg">Entities</h2>
            </div>
            <ul className="divide-y divide-border">
              {model.entities.map((e) => {
                const conf = e.fields.filter((f) => f.status === "confirmed").length;
                const epct = Math.round((conf / e.fields.length) * 100);
                return (
                  <li key={e.id} className="flex items-center gap-2 px-3 py-2">
                    <span className="min-w-0 flex-1">
                      <span className="text-sm font-medium text-fg">{e.label}</span>
                      <span className="ml-1.5 font-mono text-2xs text-fg-subtle">{e.type}</span>
                    </span>
                    <span className={`font-mono text-2xs tabular-nums ${epct === 100 ? "text-success" : "text-fg-muted"}`}>
                      {conf}/{e.fields.length}
                    </span>
                    <span className="h-1 w-10 overflow-hidden rounded-full bg-surface-inset">
                      <span className={`block h-full rounded-full ${epct === 100 ? "bg-success" : "bg-accent"}`} style={{ width: `${epct}%` }} />
                    </span>
                  </li>
                );
              })}
            </ul>
          </div>

          {/* SOURCE FILES */}
          <div className="rounded-lg border border-border bg-surface-raised shadow-sm">
            <div className="border-b border-border px-3 py-2">
              <h2 className="text-sm font-semibold text-fg">Mapped from</h2>
            </div>
            <ul className="grid grid-cols-1 gap-1 p-2.5 text-xs">
              {model.meta.sourceFiles.map((f) => (
                <li key={f} className="flex items-center gap-2 text-fg-muted">
                  <span className="grid size-5 shrink-0 place-items-center rounded bg-surface-inset font-mono text-2xs text-fg-subtle">◈</span>
                  <span className="truncate font-mono">{f}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* API SNIPPET */}
          <div className="rounded-lg border border-border bg-surface-raised shadow-sm">
            <div className="border-b border-border px-3 py-2">
              <h2 className="text-sm font-semibold text-fg">Fetch via API</h2>
            </div>
            <pre className="overflow-x-auto px-3 py-2.5 font-mono text-2xs leading-relaxed text-fg-muted">
              <span className="text-fg-subtle"># pull the promoted model</span>
              {"\n"}curl -fsSL <span className="text-accent">https://api.helios.example</span>/v1/models/\
              {"\n"}  <span className="text-accent">{model.meta.slug}</span>.<span>{fmt.ext}</span> \
              {"\n"}  -H <span className="text-success">"Authorization: Bearer $HELIOS_TOKEN"</span> \
              {"\n"}  -o fleet.<span>{fmt.ext}</span>
            </pre>
          </div>
        </aside>
      </div>
    </main>
  );
}
