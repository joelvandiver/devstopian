import { AppBar, Footer, appHref } from "./ds";
import { DownloadView } from "./features/DownloadView";

export default function App() {
  return (
    <>
      <AppBar active="download" maxW="max-w-[1480px]" />
      <DownloadView />
      <Footer maxW="max-w-[1480px]">
        <a href={appHref("design-guide")} className="ml-auto text-xs text-fg-subtle hover:text-fg">
          ← Back to overview
        </a>
      </Footer>
    </>
  );
}
