import { http, HttpResponse } from "msw";
import { FORMATS, SubstrateModel } from "../ds/model";

/* =============================================================================
   Download API (mocked). Reads the promoted model from localStorage('substrate-
   model') (falls back to the seed), and exports it as JSON / YAML / CSV / NDJSON
   with the right Content-Type. MSW browser handlers run in the page, so
   localStorage written by the Promote app is visible here.
   ========================================================================== */

export const handlers = [
  http.get("/api/model", () => HttpResponse.json(SubstrateModel.load())),

  http.get("/api/model/export/:format", ({ params }) => {
    const fmt = FORMATS.find((f) => f.id === params.format);
    if (!fmt) return new HttpResponse(null, { status: 404 });
    const text = fmt.fn(SubstrateModel.load());
    return new HttpResponse(text, {
      headers: {
        "Content-Type": fmt.mime,
        "Content-Disposition": `attachment; filename="${SubstrateModel.load().meta.slug}.${fmt.ext}"`,
      },
    });
  }),
];
