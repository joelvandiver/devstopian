import { http, HttpResponse } from "msw";

/* =============================================================================
   Upload API (mocked). An in-memory store advances each upload's progress from
   the elapsed wall-clock time — larger files take longer, ~10% fail partway —
   reproducing upload.html's simulateUpload, but server-side so TanStack Query
   drives it by polling GET /api/uploads.
   ========================================================================== */

export type UploadStatus = "uploading" | "ready" | "error";

export interface Upload {
  id: string;
  name: string;
  size: number;
  status: UploadStatus;
  progress: number;
}

interface UploadRec extends Upload {
  startedAt: number;
  durationMs: number;
  willFail: boolean;
  cap: number; // % at which a failing upload halts
}

export interface SampleFile {
  name: string;
  size: number;
}

const SAMPLES: SampleFile[] = [
  { name: "rack-manifest-iad7.csv", size: 184320 },
  { name: "telemetry-us-east-2.json", size: 5872026 },
  { name: "cooling-loop-b.yaml", size: 12480 },
  { name: "topology-spine-leaf.graphml", size: 942080 },
  { name: "power-audit-q2.xlsx", size: 2310144 },
  { name: "firmware-bundle-v4.2.tar.gz", size: 268435456 },
];

const store = new Map<string, UploadRec>();
let seq = 0;

function durationFor(size: number): number {
  // 1.5s floor, grows with size, capped at 7s
  return Math.min(7000, 1500 + size / 50000);
}

/** Recompute live progress/status for a record from elapsed time. */
function project(r: UploadRec): Upload {
  if (r.status !== "uploading") {
    return { id: r.id, name: r.name, size: r.size, status: r.status, progress: r.progress };
  }
  const pct = Math.min(100, ((Date.now() - r.startedAt) / r.durationMs) * 100);
  if (r.willFail && pct >= r.cap) {
    r.status = "error";
    r.progress = Math.round(r.cap);
  } else if (!r.willFail && pct >= 100) {
    r.status = "ready";
    r.progress = 100;
  } else {
    r.progress = Math.round(pct);
  }
  return { id: r.id, name: r.name, size: r.size, status: r.status, progress: r.progress };
}

function list(): Upload[] {
  return [...store.values()].map(project);
}

function create(name: string, size: number): Upload {
  const id = String(++seq);
  const willFail = Math.random() < 0.1;
  const rec: UploadRec = {
    id,
    name,
    size,
    status: "uploading",
    progress: 0,
    startedAt: Date.now(),
    durationMs: durationFor(size),
    willFail,
    cap: willFail ? 40 + Math.random() * 40 : 100,
  };
  store.set(id, rec);
  return project(rec);
}

export const handlers = [
  http.get("/api/uploads/samples", () => HttpResponse.json(SAMPLES)),

  http.get("/api/uploads", () => HttpResponse.json(list())),

  http.get("/api/uploads/:id", ({ params }) => {
    const r = store.get(String(params.id));
    if (!r) return new HttpResponse(null, { status: 404 });
    return HttpResponse.json(project(r));
  }),

  http.post("/api/uploads", async ({ request }) => {
    const body = (await request.json()) as { name: string; size: number };
    return HttpResponse.json(create(body.name, body.size), { status: 201 });
  }),

  http.delete("/api/uploads/:id", ({ params }) => {
    store.delete(String(params.id));
    return new HttpResponse(null, { status: 204 });
  }),

  http.delete("/api/uploads", () => {
    store.clear();
    return new HttpResponse(null, { status: 204 });
  }),
];
