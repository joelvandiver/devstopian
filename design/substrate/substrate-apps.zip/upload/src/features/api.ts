import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { SampleFile, Upload } from "../api/handlers";

async function getJSON<T>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${res.status} ${url}`);
  return res.json() as Promise<T>;
}

export function useUploads() {
  return useQuery({
    queryKey: ["uploads"],
    queryFn: () => getJSON<Upload[]>("/api/uploads"),
    // poll while anything is still uploading
    refetchInterval: (q) =>
      (q.state.data ?? []).some((u) => u.status === "uploading") ? 350 : false,
  });
}

export function useSamples() {
  return useQuery({ queryKey: ["samples"], queryFn: () => getJSON<SampleFile[]>("/api/uploads/samples") });
}

export function useCreateUpload() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (file: { name: string; size: number }) => {
      const res = await fetch("/api/uploads", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(file),
      });
      if (!res.ok) throw new Error("upload failed");
      return res.json() as Promise<Upload>;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["uploads"] }),
  });
}

export function useDeleteUpload() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => fetch(`/api/uploads/${id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["uploads"] }),
  });
}

export function useClearUploads() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => fetch("/api/uploads", { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["uploads"] }),
  });
}
