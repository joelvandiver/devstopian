import { useRef, useState } from "react";
import { appHref, ProgressBar, StatusBadge } from "../ds";
import {
  useClearUploads,
  useCreateUpload,
  useDeleteUpload,
  useSamples,
  useUploads,
} from "./api";
import { fmtBytes, glyphFor } from "./format";
import type { Upload } from "../api/handlers";

function FileRow({ u, onRemove }: { u: Upload; onRemove: () => void }) {
  const badge =
    u.status === "ready" ? (
      <StatusBadge tone="success">READY</StatusBadge>
    ) : u.status === "error" ? (
      <StatusBadge tone="danger">FAILED</StatusBadge>
    ) : (
      <StatusBadge tone="info" live>
        UPLOADING
      </StatusBadge>
    );
  const barTone = u.status === "ready" ? "success" : u.status === "error" ? "danger" : "accent";
  return (
    <li className="flex items-center gap-3 px-3 py-2">
      <span className="grid size-8 shrink-0 place-items-center rounded-md bg-surface-inset font-mono text-sm text-fg-muted">
        {glyphFor(u.name)}
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="truncate text-sm font-medium text-fg" title={u.name}>
            {u.name}
          </span>
          <span className="shrink-0 font-mono text-2xs text-fg-subtle">{fmtBytes(u.size)}</span>
          <span className="ml-auto shrink-0">{badge}</span>
        </div>
        <div className="mt-1.5">
          <ProgressBar value={u.progress} tone={barTone} />
        </div>
      </div>
      <button
        onClick={onRemove}
        aria-label="Remove file"
        className="shrink-0 rounded p-1 text-fg-subtle hover:bg-hover hover:text-danger"
      >
        ✕
      </button>
    </li>
  );
}

const ACCEPTED = [
  { glyph: "⌗", label: ".csv manifests" },
  { glyph: "{ }", label: ".json telemetry" },
  { glyph: "▤", label: ".yaml configs" },
  { glyph: "◇", label: ".graphml topo" },
  { glyph: "▦", label: ".xlsx audits" },
  { glyph: "▣", label: ".tar.gz bundles" },
];

export function UploadView() {
  const { data: uploads = [] } = useUploads();
  const { data: samples = [] } = useSamples();
  const create = useCreateUpload();
  const remove = useDeleteUpload();
  const clear = useClearUploads();
  const fileInput = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [sampleIdx, setSampleIdx] = useState(0);

  const ready = uploads.filter((u) => u.status === "ready").length;
  const total = uploads.reduce((s, u) => s + u.size, 0);

  function addFiles(files: { name: string; size: number }[]) {
    files.forEach((f) => create.mutate({ name: f.name, size: f.size }));
  }

  return (
    <main className="mx-auto max-w-[1100px] px-4 py-8">
      <div className="mb-5 border-b border-border pb-3">
        <h1 className="text-2xl font-bold tracking-tight text-fg">Upload infrastructure files</h1>
        <p className="mt-1 max-w-3xl text-base text-fg-muted text-pretty">
          Drag rack manifests, telemetry dumps, topology graphs or firmware bundles onto the drop
          zone. Files are queued, then handed to the processing{" "}
          <a href={appHref("agents")} className="font-medium text-accent hover:underline">
            agent pipeline
          </a>
          .
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          {/* DROP ZONE */}
          <div
            role="button"
            tabIndex={0}
            aria-label="Upload files: drag and drop or activate to browse"
            onClick={() => fileInput.current?.click()}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                fileInput.current?.click();
              }
            }}
            onDragEnter={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={(e) => {
              if (!e.currentTarget.contains(e.relatedTarget as Node)) setDragging(false);
            }}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              const list = Array.from(e.dataTransfer.files).map((f) => ({ name: f.name, size: f.size }));
              if (list.length) addFiles(list);
            }}
            className={`group relative grid cursor-pointer place-items-center rounded-xl border-2 border-dashed px-6 py-12 text-center transition-colors ${
              dragging
                ? "border-accent bg-accent-muted"
                : "border-border bg-surface-raised hover:border-accent-border hover:bg-accent-muted/30"
            }`}
          >
            <div className="pointer-events-none flex flex-col items-center gap-3">
              <span className="grid size-12 place-items-center rounded-xl border border-border bg-surface text-xl text-accent transition-transform group-hover:-translate-y-0.5">
                ↑
              </span>
              <div>
                <p className="text-md font-semibold text-fg">
                  {dragging ? "Release to upload" : "Drag & drop files here"}
                </p>
                <p className="mt-1 text-sm text-fg-muted">
                  or <span className="font-medium text-accent">browse</span> — CSV, JSON, YAML,
                  GraphML, XLSX, TAR · up to 2&nbsp;GB each
                </p>
              </div>
            </div>
            <input
              ref={fileInput}
              type="file"
              multiple
              className="sr-only"
              aria-hidden="true"
              onChange={(e) => {
                const list = Array.from(e.target.files ?? []).map((f) => ({ name: f.name, size: f.size }));
                if (list.length) addFiles(list);
                e.target.value = "";
              }}
            />
          </div>

          {/* QUEUE */}
          <div className="rounded-lg border border-border bg-surface-raised shadow-sm">
            <div className="flex items-center gap-3 border-b border-border px-3 py-2">
              <h2 className="text-sm font-semibold text-fg">Upload queue</h2>
              <span className="inline-flex items-center rounded-full bg-accent-muted px-2 py-0.5 text-2xs font-medium text-accent">
                {uploads.length} {uploads.length === 1 ? "file" : "files"}
              </span>
              <div className="ml-auto flex items-center gap-2">
                <button
                  onClick={() => {
                    const s = samples[sampleIdx % (samples.length || 1)];
                    if (s) {
                      create.mutate({ name: s.name, size: s.size });
                      setSampleIdx((i) => i + 1);
                    }
                  }}
                  className="rounded-md border border-border bg-surface px-2.5 py-1 text-xs font-medium text-fg hover:bg-hover"
                >
                  Add sample file
                </button>
                <button
                  onClick={() => clear.mutate()}
                  className="rounded-md px-2.5 py-1 text-xs font-medium text-fg-muted hover:bg-hover hover:text-danger"
                >
                  Clear all
                </button>
              </div>
            </div>

            {uploads.length === 0 ? (
              <div className="px-3 py-10 text-center">
                <p className="text-sm text-fg-muted">No files queued yet.</p>
                <p className="mt-0.5 text-xs text-fg-subtle">
                  Drop files above or add a sample to see the flow.
                </p>
              </div>
            ) : (
              <ul className="divide-y divide-border" aria-live="polite">
                {uploads.map((u) => (
                  <FileRow key={u.id} u={u} onRemove={() => remove.mutate(u.id)} />
                ))}
              </ul>
            )}

            <div className="flex items-center gap-3 border-t border-border bg-surface-sunken px-3 py-2">
              <span className="font-mono text-2xs text-fg-subtle">
                Total: <span className="text-fg-muted">{fmtBytes(total)}</span>
              </span>
              <span className="font-mono text-2xs text-fg-subtle">
                · <span className="text-success">{ready}</span> ready
              </span>
              <a
                href={appHref("agents")}
                className={`ml-auto inline-flex items-center gap-1.5 rounded-md bg-accent px-3 py-1.5 text-sm font-medium text-fg-on-accent hover:bg-accent-hover ${
                  ready > 0 ? "" : "pointer-events-none opacity-50"
                }`}
              >
                Process {ready} files&nbsp;→
              </a>
            </div>
          </div>
        </div>

        {/* SIDEBAR */}
        <aside className="space-y-4">
          <div className="rounded-lg border border-border bg-surface-raised p-3 shadow-sm">
            <h3 className="text-sm font-semibold text-fg">Accepted formats</h3>
            <ul className="mt-2 grid grid-cols-2 gap-1.5 text-xs">
              {ACCEPTED.map((a) => (
                <li key={a.label} className="flex items-center gap-2 text-fg-muted">
                  <span className="grid size-5 place-items-center rounded bg-surface-inset text-fg-subtle">
                    {a.glyph}
                  </span>{" "}
                  {a.label}
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-lg border border-border bg-surface-raised p-3 shadow-sm">
            <h3 className="text-sm font-semibold text-fg">What happens next</h3>
            <ol className="mt-2 space-y-2 text-xs text-fg-muted">
              {[
                "Files upload & are checksummed on arrival.",
                "Each is queued to the agent pipeline.",
                "Agents parse, classify, validate & index in turn.",
              ].map((t, i) => (
                <li key={i} className="flex gap-2">
                  <span className="grid size-4 shrink-0 place-items-center rounded-full bg-accent-muted font-mono text-2xs text-accent">
                    {i + 1}
                  </span>{" "}
                  {t}
                </li>
              ))}
            </ol>
            <a
              href={appHref("agents")}
              className="mt-3 inline-flex items-center gap-1.5 text-xs font-medium text-accent hover:underline"
            >
              Watch the pipeline&nbsp;→
            </a>
          </div>
          <div className="rounded-lg border border-info-border bg-info-bg p-3">
            <p className="text-xs font-medium text-info">Tip</p>
            <p className="mt-1 text-xs text-info/80">
              Drag a whole folder of telemetry — every file is queued individually and processed in
              order.
            </p>
          </div>
        </aside>
      </div>
    </main>
  );
}
