export function glyphFor(name: string): string {
  const n = name.toLowerCase();
  if (n.endsWith(".csv")) return "⌗";
  if (n.endsWith(".json")) return "{ }";
  if (n.endsWith(".yaml") || n.endsWith(".yml")) return "▤";
  if (n.endsWith(".graphml") || n.endsWith(".xml")) return "◇";
  if (n.endsWith(".xlsx") || n.endsWith(".xls")) return "▦";
  if (/\.(tar|gz|zip|tgz)$/.test(n)) return "▣";
  return "▪";
}

export function fmtBytes(b: number): string {
  if (b < 1024) return b + " B";
  const u = ["KB", "MB", "GB", "TB"];
  let i = -1;
  do {
    b /= 1024;
    i++;
  } while (b >= 1024 && i < u.length - 1);
  return (b >= 100 ? b.toFixed(0) : b.toFixed(1)) + " " + u[i];
}
