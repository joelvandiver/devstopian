import { AppBar, Footer, appHref } from "./ds";
import { UploadView } from "./features/UploadView";

export default function App() {
  return (
    <>
      <AppBar active="upload" maxW="max-w-[1480px]" />
      <UploadView />
      <Footer maxW="max-w-[1480px]">
        <a href={appHref("design-guide")} className="ml-auto text-xs text-fg-subtle hover:text-fg">
          ← Back to overview
        </a>
      </Footer>
    </>
  );
}
