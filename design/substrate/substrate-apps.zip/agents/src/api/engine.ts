/* =============================================================================
   Agent pipeline engine (deterministic), ported from observability.html's
   buildState. Produces a static PLAN (files × agents with span start/dur) plus
   a time-ordered list of data EVENTS. The MSW stream replays the events in
   real time; the client renders live bars from the plan + a running clock.
   ========================================================================== */

export type Level = "info" | "warn" | "error";
export type SpanStatus = "done" | "warn" | "error";

export interface AgentMeta {
  key: string;
  name: string;
  glyph: string;
  desc: string;
}

export interface AgentPlan extends AgentMeta {
  start: number; // absolute sim ms
  dur: number;
}

export interface FilePlan {
  name: string;
  glyph: string;
  records: number;
  kb: number;
  start: number;
  total: number;
  agents: AgentPlan[];
}

export type RunEvent =
  | { type: "span-start"; t: number; fi: number; ai: number }
  | { type: "span-end"; t: number; fi: number; ai: number; status: SpanStatus; detail: string; tokens: number }
  | { type: "log"; t: number; agent: string; file: string; level: Level; msg: string }
  | { type: "file-end"; t: number; fi: number; status: "done" | "failed"; records: number };

export interface Plan {
  agents: AgentMeta[];
  files: FilePlan[];
  events: RunEvent[];
  end: number;
}

const AGENTS: AgentMeta[] = [
  { key: "ingest", name: "Ingest", glyph: "▤", desc: "read · checksum" },
  { key: "parse", name: "Parse", glyph: "⌗", desc: "extract records" },
  { key: "classify", name: "Classify", glyph: "◈", desc: "LLM tag · normalize" },
  { key: "validate", name: "Validate", glyph: "✓", desc: "schema · policy" },
  { key: "index", name: "Index", glyph: "⛁", desc: "commit to fleet" },
];

const BASE: Record<string, number> = {
  ingest: 700,
  parse: 1500,
  classify: 2300,
  validate: 950,
  index: 1200,
};

interface SrcFile {
  name: string;
  glyph: string;
  records: number;
  kb: number;
  warnAt?: string;
  warns?: number;
  errAt?: string;
}

const SRC: SrcFile[] = [
  { name: "rack-manifest-iad7.csv", glyph: "⌗", records: 1204, kb: 180 },
  { name: "telemetry-us-east-2.json", glyph: "{}", records: 48210, kb: 5734 },
  { name: "cooling-loop-b.yaml", glyph: "▤", records: 96, kb: 12, warnAt: "validate", warns: 2 },
  { name: "topology-spine-leaf.graphml", glyph: "◇", records: 3120, kb: 920 },
  { name: "power-audit-q2.xlsx", glyph: "▦", records: 842, kb: 2256 },
  { name: "firmware-bundle-v4.2.tar.gz", glyph: "▣", records: 12, kb: 262144, errAt: "index" },
];

const FGAP = 600;
const AGAP = 120;

function fmt(n: number): string {
  return n.toLocaleString("en-US");
}

export function buildPlan(): Plan {
  // seeded RNG for a stable run
  let seed = 1337;
  const rng = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return seed / 0x7fffffff;
  };
  const jit = (b: number, spread: number) => Math.round(b * (1 - spread + rng() * spread * 2));

  const files: FilePlan[] = [];
  const events: RunEvent[] = [];
  let cursor = 0;

  SRC.forEach((s, fi) => {
    const fileStart = cursor;
    const agents: AgentPlan[] = [];

    AGENTS.forEach((a, ai) => {
      const recFactor =
        a.key === "parse" || a.key === "classify" || a.key === "index"
          ? 0.7 + Math.min(s.records / 20000, 1.6)
          : 1;
      const dur = jit(BASE[a.key] * recFactor, 0.18);
      const startT = cursor;
      const endT = cursor + dur;

      let tokens = 0;
      let level: Level = "info";
      let detail = "";
      if (a.key === "ingest")
        detail = "sha256 ✓ · " + (s.kb >= 1024 ? (s.kb / 1024).toFixed(1) + " MB" : s.kb + " KB");
      if (a.key === "parse") detail = fmt(s.records) + " records";
      if (a.key === "classify") {
        tokens = Math.min(6000, Math.round(140 + s.records * 0.09));
        detail = fmt(tokens) + " tok · " + (3 + (fi % 4)) + " tags";
      }
      if (a.key === "validate") {
        if (s.warnAt === "validate") {
          level = "warn";
          detail = s.warns + " warnings";
        } else detail = "0 issues";
      }
      if (a.key === "index") {
        if (s.errAt === "index") {
          level = "error";
          detail = "write conflict — retry exhausted";
        } else detail = "committed · " + fmt(s.records) + " rows";
      }

      agents.push({ ...a, start: startT, dur });

      events.push({ type: "span-start", t: startT, fi, ai });
      events.push({ type: "log", t: startT, agent: a.key, file: s.name, level: "info", msg: "start" });
      const spanStatus: SpanStatus = level === "error" ? "error" : level === "warn" ? "warn" : "done";
      events.push({ type: "span-end", t: endT, fi, ai, status: spanStatus, detail, tokens });
      events.push({ type: "log", t: endT, agent: a.key, file: s.name, level, msg: detail });

      cursor = endT + AGAP;
    });

    const total = cursor - fileStart - AGAP;
    files.push({ name: s.name, glyph: s.glyph, records: s.records, kb: s.kb, start: fileStart, total, agents });

    const failed = !!s.errAt;
    events.push({ type: "file-end", t: cursor, fi, status: failed ? "failed" : "done", records: s.records });
    cursor += FGAP;
  });

  // stable order by time
  events.sort((a, b) => a.t - b.t);

  return { agents: AGENTS, files, events, end: cursor };
}
