import { http, HttpResponse } from "msw";
import { buildPlan, type AgentMeta, type FilePlan } from "./engine";

/* =============================================================================
   Agent pipeline API (mocked, streaming).
     POST /api/runs              -> start/restart a run; returns the static plan
     GET  /api/runs/:id/stream   -> NDJSON ReadableStream of timed events
     POST /api/runs/:id/pause|resume|speed -> control the live stream pace
   A module-level registry lets the control endpoints steer the in-flight stream.
   ========================================================================== */

interface Run {
  id: string;
  plan: ReturnType<typeof buildPlan>;
  speed: number;
  paused: boolean;
  aborted: boolean;
}

const runs = new Map<string, Run>();
let seq = 0;

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export interface RunMeta {
  runId: string;
  agents: AgentMeta[];
  files: FilePlan[];
  end: number;
}

export const handlers = [
  // start / restart
  http.post("/api/runs", () => {
    const id = String(++seq);
    const run: Run = { id, plan: buildPlan(), speed: 2, paused: false, aborted: false };
    runs.set(id, run);
    const meta: RunMeta = { runId: id, agents: run.plan.agents, files: run.plan.files, end: run.plan.end };
    return HttpResponse.json(meta, { status: 201 });
  }),

  http.post("/api/runs/:id/pause", ({ params }) => {
    const run = runs.get(String(params.id));
    if (run) run.paused = true;
    return new HttpResponse(null, { status: 204 });
  }),

  http.post("/api/runs/:id/resume", ({ params }) => {
    const run = runs.get(String(params.id));
    if (run) run.paused = false;
    return new HttpResponse(null, { status: 204 });
  }),

  http.post("/api/runs/:id/speed", async ({ params, request }) => {
    const run = runs.get(String(params.id));
    const body = (await request.json()) as { speed: number };
    if (run) run.speed = body.speed;
    return new HttpResponse(null, { status: 204 });
  }),

  // the live event stream
  http.get("/api/runs/:id/stream", ({ params }) => {
    const run = runs.get(String(params.id));
    if (!run) return new HttpResponse(null, { status: 404 });

    const encoder = new TextEncoder();
    const { events, end } = run.plan;

    const stream = new ReadableStream<Uint8Array>({
      async start(controller) {
        run.aborted = false;
        const enc = (o: unknown) => controller.enqueue(encoder.encode(JSON.stringify(o) + "\n"));
        const STEP_REAL = 90; // real ms per loop
        const STEP_SIM = 90; // sim ms advanced per loop (× speed)
        let simT = 0;
        let idx = 0;
        let lastTick = 0;

        while (simT < end && !run.aborted) {
          if (run.paused) {
            await sleep(80);
            continue;
          }
          await sleep(STEP_REAL);
          simT += STEP_SIM * run.speed;
          while (idx < events.length && events[idx].t <= simT) {
            enc(events[idx]);
            idx++;
          }
          if (simT - lastTick >= 120) {
            enc({ type: "tick", t: Math.min(simT, end) });
            lastTick = simT;
          }
        }
        if (!run.aborted) {
          enc({ type: "tick", t: end });
          enc({ type: "done", t: end });
        }
        controller.close();
      },
      cancel() {
        run.aborted = true;
      },
    });

    return new HttpResponse(stream, {
      headers: { "Content-Type": "application/x-ndjson", "Cache-Control": "no-store" },
    });
  }),
];
