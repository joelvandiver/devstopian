import { AppBar, Footer, appHref } from "./ds";
import { AgentsView } from "./features/AgentsView";

export default function App() {
  return (
    <>
      <AppBar active="agents" maxW="max-w-[1600px]" />
      <AgentsView />
      <Footer maxW="max-w-[1600px]">
        <a href={appHref("upload")} className="ml-auto text-xs text-fg-subtle hover:text-fg">
          ← Upload more files
        </a>
      </Footer>
    </>
  );
}
