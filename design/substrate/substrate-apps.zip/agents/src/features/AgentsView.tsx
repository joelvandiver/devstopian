import { appHref, KpiStrip, StatusBadge, type KpiCell } from "../ds";
import { useRun } from "./useRun";
import type { AgentStatus, FileState, RunState } from "./run";

const fmt = (n: number) => n.toLocaleString("en-US");
function clock(ms: number): string {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  return (m > 0 ? m + "m " : "") + (s % 60) + "." + Math.floor((ms % 1000) / 100) + "s";
}

const PIP: Record<AgentStatus, string> = {
  idle: "bg-border",
  running: "bg-info ds-live",
  done: "bg-success",
  warn: "bg-warning",
  error: "bg-danger",
};
const STATUS_TEXT: Record<AgentStatus, string> = {
  idle: "text-fg-subtle",
  running: "text-info",
  done: "text-success",
  warn: "text-warning",
  error: "text-danger",
};
const BAR: Record<AgentStatus, string> = {
  idle: "bg-border",
  running: "bg-info ds-live",
  done: "bg-accent",
  warn: "bg-warning",
  error: "bg-danger",
};
const LOG_LEVEL: Record<string, string> = {
  info: "text-fg-muted",
  warn: "text-warning",
  error: "text-danger",
};

function fileBadge(f: FileState) {
  if (f.status === "done") return <StatusBadge tone="success">DONE</StatusBadge>;
  if (f.status === "failed") return <StatusBadge tone="danger">FAILED</StatusBadge>;
  if (f.status === "processing")
    return (
      <StatusBadge tone="info" live>
        RUNNING
      </StatusBadge>
    );
  return <StatusBadge tone="neutral" pip={false}>QUEUED</StatusBadge>;
}

function Kpis({ st }: { st: RunState }) {
  const thru = st.T > 0 ? Math.round(st.processedRecords / (st.T / 1000)) : 0;
  const done = st.files.filter((f) => f.status === "done" || f.status === "failed");
  const avg = done.length ? Math.round(done.reduce((s, f) => s + f.total, 0) / done.length) : 0;
  const inflight = st.files.filter((f) => f.status === "processing").length;
  const cells: KpiCell[] = [
    { label: "Completed", value: `${st.completed} / ${st.files.length}` },
    { label: "In flight", value: String(inflight), valueClass: "text-info" },
    { label: "Failed", value: String(st.failed), valueClass: st.failed ? "text-danger" : "text-fg" },
    { label: "Tokens used", value: fmt(st.tokens) },
    {
      label: "Throughput",
      value: (
        <>
          {fmt(thru)} <span className="text-xs font-normal text-fg-subtle">rec/s</span>
        </>
      ),
    },
    {
      label: "Avg latency",
      value: avg ? (
        <>
          {(avg / 1000).toFixed(1)} <span className="text-xs font-normal text-fg-subtle">s</span>
        </>
      ) : (
        "—"
      ),
    },
  ];
  return <KpiStrip cells={cells} />;
}

function Trace({ st }: { st: RunState }) {
  const f = st.files[st.selected];
  const total = f.total || 1;
  return (
    <div className="p-3">
      <div className="mb-2 flex items-center gap-3 text-2xs font-mono uppercase tracking-wide text-fg-subtle">
        <span className="w-36 shrink-0">Agent</span>
        <span className="flex-1">Span</span>
        <span className="w-44 shrink-0 text-right">Detail</span>
      </div>
      {f.agents.map((a, i) => {
        const leftPct = ((a.start - f.start) / total) * 100;
        const shown =
          a.status === "running"
            ? Math.max(0, Math.min(a.dur, st.T - a.start))
            : a.status === "idle"
              ? 0
              : a.dur;
        const wPct = Math.max((shown / total) * 100, a.status === "idle" ? 0 : 1.5);
        const durLabel =
          a.status === "idle" ? "" : a.status === "running" ? Math.round(shown) + "ms" : a.dur + "ms";
        return (
          <div key={i} className="flex items-center gap-3 py-1.5">
            <div className="flex w-36 shrink-0 items-center gap-2">
              <span className={`grid size-5 place-items-center rounded bg-surface-inset font-mono text-2xs ${STATUS_TEXT[a.status]}`}>
                {a.glyph}
              </span>
              <span className="text-sm font-medium text-fg">{a.name}</span>
            </div>
            <div className="relative h-6 flex-1 overflow-hidden rounded bg-surface-sunken">
              <div
                className={`absolute top-0 bottom-0 rounded ${BAR[a.status]}`}
                style={{ left: `${leftPct}%`, width: `${wPct}%` }}
              />
            </div>
            <div className="w-44 shrink-0 text-right">
              <span className={`font-mono text-2xs ${STATUS_TEXT[a.status]}`}>{durLabel}</span>
              {a.detail && <span className="ml-1 font-mono text-2xs text-fg-subtle">{a.detail}</span>}
            </div>
          </div>
        );
      })}
      {f.status === "queued" && <p className="mt-2 text-xs text-fg-subtle">Waiting in queue…</p>}
      {f.status === "failed" && (
        <p className="mt-3 rounded-md border border-danger-border bg-danger-bg px-3 py-2 text-xs text-danger">
          Pipeline halted at <span className="font-semibold">Index</span> — write conflict after 3
          retries. File quarantined.
        </p>
      )}
      {f.status === "done" && (
        <p className="mt-3 rounded-md border border-success-border bg-success-bg px-3 py-2 text-xs text-success">
          Committed to fleet model in {(f.total / 1000).toFixed(1)}s · {fmt(f.tokens)} tokens.
        </p>
      )}
    </div>
  );
}

export function AgentsView() {
  const { state: st, paused, speed, start, togglePause, setSpeed, select, setFollow } = useRun();

  if (!st) return <main className="mx-auto max-w-[1600px] px-4 py-10 text-sm text-fg-muted">Starting run…</main>;

  const runStateBadge =
    !st.running && st.T >= st.end ? (
      <StatusBadge tone="success">RUN COMPLETE</StatusBadge>
    ) : paused ? (
      <StatusBadge tone="warning">PAUSED</StatusBadge>
    ) : (
      <StatusBadge tone="info" live>
        RUNNING
      </StatusBadge>
    );

  const active = st.files.find((f) => f.status === "processing");

  return (
    <main className="mx-auto max-w-[1600px] px-4 py-5">
      {/* TITLE + CONTROLS */}
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3 border-b border-border pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-fg">Agent pipeline</h1>
            {runStateBadge}
          </div>
          <p className="mt-1 text-sm text-fg-muted">
            Each uploaded file is processed by five agents in turn — Ingest → Parse → Classify →
            Validate → Index. Live traces, spans and events below.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="inline-flex items-center gap-1 rounded-md border border-border bg-surface p-0.5 text-xs" role="group" aria-label="Playback speed">
            {[1, 2, 4].map((s) => (
              <button
                key={s}
                onClick={() => setSpeed(s)}
                aria-pressed={speed === s}
                className={`rounded px-2 py-1 font-medium ${speed === s ? "bg-accent text-fg-on-accent" : "text-fg-muted hover:text-fg"}`}
              >
                {s}×
              </button>
            ))}
          </div>
          <button
            onClick={togglePause}
            className="inline-flex items-center gap-1.5 rounded-md border border-border bg-surface px-3 py-1.5 text-sm font-medium text-fg hover:bg-hover"
          >
            {paused ? "Resume" : "Pause"}
          </button>
          <button
            onClick={start}
            className="inline-flex items-center gap-1.5 rounded-md bg-accent px-3 py-1.5 text-sm font-medium text-fg-on-accent hover:bg-accent-hover"
          >
            Restart
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="mb-4">
        <Kpis st={st} />
      </div>

      {/* MAIN GRID */}
      <div className="grid gap-4 xl:grid-cols-[300px_1fr_320px]">
        {/* FILE QUEUE */}
        <section className="rounded-lg border border-border bg-surface-raised shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-3 py-2">
            <h2 className="text-sm font-semibold text-fg">Run queue</h2>
            <label className="flex items-center gap-1.5 text-2xs text-fg-muted">
              <input
                type="checkbox"
                checked={st.follow}
                onChange={(e) => setFollow(e.target.checked)}
                className="size-3.5 rounded border-border text-accent focus:ring-ring/40"
              />{" "}
              follow live
            </label>
          </div>
          <ul className="divide-y divide-border">
            {st.files.map((f, i) => {
              const sel = i === st.selected;
              return (
                <li key={f.name}>
                  <button
                    onClick={() => select(i)}
                    className={`flex w-full items-center gap-2 px-3 py-2 text-left ${sel ? "bg-selected" : "hover:bg-hover"}`}
                  >
                    <span className="grid size-7 shrink-0 place-items-center rounded bg-surface-inset font-mono text-xs text-fg-muted">
                      {f.glyph}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-1.5">
                        <span className={`truncate text-sm font-medium ${sel ? "text-accent" : "text-fg"}`}>
                          {f.name}
                        </span>
                      </span>
                      <span className="mt-1 flex items-center gap-1">
                        {f.agents.map((a, ai) => (
                          <span key={ai} className={`size-1.5 rounded-full ${PIP[a.status]}`} />
                        ))}
                        <span className="ml-1 font-mono text-2xs text-fg-subtle">{fmt(f.records)} rec</span>
                      </span>
                    </span>
                    <span className="shrink-0">{fileBadge(f)}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>

        {/* TRACE */}
        <section className="rounded-lg border border-border bg-surface-raised shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-3 py-2">
            <h2 className="text-sm font-semibold text-fg">Trace</h2>
            <span className="font-mono text-2xs text-fg-subtle">
              {st.files[st.selected].name} ·{" "}
              {st.files[st.selected].total ? (st.files[st.selected].total / 1000).toFixed(1) + "s" : "—"}
            </span>
          </div>
          <Trace st={st} />
        </section>

        {/* ROSTER + LOGS */}
        <section className="flex min-h-0 flex-col gap-4">
          <div className="rounded-lg border border-border bg-surface-raised shadow-sm">
            <div className="border-b border-border px-3 py-2">
              <h2 className="text-sm font-semibold text-fg">Agents</h2>
            </div>
            <ul className="divide-y divide-border">
              {st.agents.map((a, ai) => {
                const processed = st.files.filter((f) =>
                  ["done", "warn", "error"].includes(f.agents[ai].status),
                ).length;
                const isRunning = !!active && active.agents[ai].status === "running";
                return (
                  <li key={a.key} className="flex items-center gap-2.5 px-3 py-2">
                    <span className={`grid size-7 shrink-0 place-items-center rounded-md bg-surface-inset font-mono text-xs ${isRunning ? "text-info" : "text-fg-muted"}`}>
                      {a.glyph}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-fg">{a.name}</p>
                      <p className={`font-mono text-2xs ${isRunning ? "text-info" : "text-fg-subtle"}`}>
                        {isRunning ? "processing " + active!.name : a.desc}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      <span className={`size-1.5 rounded-full ${isRunning ? "bg-info ds-live" : "bg-border"}`} />
                      <span className="font-mono text-2xs text-fg-subtle">
                        {processed}/{st.files.length}
                      </span>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>

          <div className="flex min-h-0 flex-1 flex-col rounded-lg border border-border bg-surface-raised shadow-sm">
            <div className="flex items-center justify-between border-b border-border px-3 py-2">
              <h2 className="text-sm font-semibold text-fg">Event log</h2>
              <span className="font-mono text-2xs text-fg-subtle">{st.logs.length} events</span>
            </div>
            <div className="h-[360px] overflow-y-auto px-3 py-2 font-mono text-2xs leading-relaxed" aria-live="polite">
              {st.logs.map((l, i) => (
                <div key={i} className="flex gap-2">
                  <span className="shrink-0 text-fg-subtle">{clock(l.t)}</span>
                  <span className="shrink-0 text-accent">[{l.agent}]</span>
                  <span className={`min-w-0 flex-1 ${LOG_LEVEL[l.level]}`}>
                    <span className="text-fg-subtle">{l.file}</span> {l.msg}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>

      <div className="mt-6">
        <a href={appHref("promote")} className="text-xs font-medium text-accent hover:underline">
          Continue to promotion →
        </a>
      </div>
    </main>
  );
}
