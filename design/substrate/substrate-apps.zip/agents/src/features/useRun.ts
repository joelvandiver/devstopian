import { useCallback, useEffect, useReducer, useRef, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import type { RunMeta } from "../api/handlers";
import { initFromMeta, reducer, type RunState, type StreamEvent } from "./run";

function nullableReducer(state: RunState | null, action: Parameters<typeof reducer>[1]) {
  if (action.kind === "reset") return initFromMeta(action.meta);
  if (!state) return state;
  return reducer(state, action);
}

/* Owns the run lifecycle: TanStack Query mutations start/restart the run and
   steer pace; a fetch + ReadableStream reader feeds events into the reducer. */
export function useRun() {
  const [state, dispatch] = useReducer(nullableReducer, null);
  const [runId, setRunId] = useState<string | null>(null);
  const [paused, setPaused] = useState(false);
  const [speed, setSpeedState] = useState(2);
  const abortRef = useRef<AbortController | null>(null);

  const startMutation = useMutation({
    mutationFn: async (): Promise<RunMeta> => {
      const res = await fetch("/api/runs", { method: "POST" });
      if (!res.ok) throw new Error("failed to start run");
      return res.json();
    },
    onSuccess: (meta) => {
      dispatch({ kind: "reset", meta });
      setPaused(false);
      setSpeedState(2);
      setRunId(meta.runId);
    },
  });

  const start = useCallback(() => startMutation.mutate(), [startMutation]);

  // kick off the first run on mount
  useEffect(() => {
    startMutation.mutate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // open the event stream whenever the runId changes
  useEffect(() => {
    if (!runId) return;
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    (async () => {
      try {
        const res = await fetch(`/api/runs/${runId}/stream`, { signal: ctrl.signal });
        if (!res.body) return;
        const reader = res.body.getReader();
        const dec = new TextDecoder();
        let buf = "";
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          let nl: number;
          while ((nl = buf.indexOf("\n")) >= 0) {
            const line = buf.slice(0, nl);
            buf = buf.slice(nl + 1);
            if (line.trim()) dispatch({ kind: "event", ev: JSON.parse(line) as StreamEvent });
          }
        }
      } catch {
        /* aborted or stream ended */
      }
    })();
    return () => ctrl.abort();
  }, [runId]);

  const pauseMutation = useMutation({
    mutationFn: (action: "pause" | "resume") =>
      fetch(`/api/runs/${runId}/${action}`, { method: "POST" }),
  });
  const speedMutation = useMutation({
    mutationFn: (s: number) =>
      fetch(`/api/runs/${runId}/speed`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ speed: s }),
      }),
  });

  const togglePause = useCallback(() => {
    const next = !paused;
    setPaused(next);
    pauseMutation.mutate(next ? "pause" : "resume");
  }, [paused, pauseMutation]);

  const setSpeed = useCallback(
    (s: number) => {
      setSpeedState(s);
      speedMutation.mutate(s);
    },
    [speedMutation],
  );

  const select = useCallback((i: number) => dispatch({ kind: "select", i }), []);
  const setFollow = useCallback((on: boolean) => dispatch({ kind: "follow", on }), []);

  return { state, paused, speed, start, togglePause, setSpeed, select, setFollow };
}
