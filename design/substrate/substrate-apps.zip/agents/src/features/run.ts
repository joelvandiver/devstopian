import type { AgentMeta, AgentPlan, Level, RunEvent } from "../api/engine";
import type { RunMeta } from "../api/handlers";

/* Client-side run state + reducer. The stream feeds RunEvents (+ tick/done);
   KPIs, the trace waterfall, roster and log are all derived from this state. */

export type AgentStatus = "idle" | "running" | "done" | "warn" | "error";
export type FileStatus = "queued" | "processing" | "done" | "failed";

export interface AgentState extends AgentPlan {
  status: AgentStatus;
  detail: string;
  level: Level;
}

export interface FileState {
  name: string;
  glyph: string;
  records: number;
  kb: number;
  start: number;
  total: number;
  status: FileStatus;
  tokens: number;
  agents: AgentState[];
}

export interface LogLine {
  t: number;
  agent: string;
  file: string;
  level: Level;
  msg: string;
}

export interface RunState {
  agents: AgentMeta[];
  files: FileState[];
  end: number;
  T: number;
  tokens: number;
  completed: number;
  failed: number;
  processedRecords: number;
  logs: LogLine[];
  running: boolean;
  selected: number;
  follow: boolean;
}

export type StreamEvent = RunEvent | { type: "tick"; t: number } | { type: "done"; t: number };

export type Action =
  | { kind: "reset"; meta: RunMeta }
  | { kind: "event"; ev: StreamEvent }
  | { kind: "select"; i: number }
  | { kind: "follow"; on: boolean };

export function initFromMeta(meta: RunMeta): RunState {
  return {
    agents: meta.agents,
    end: meta.end,
    files: meta.files.map((f) => ({
      ...f,
      status: "queued",
      tokens: 0,
      agents: f.agents.map((a) => ({ ...a, status: "idle", detail: "", level: "info" as Level })),
    })),
    T: 0,
    tokens: 0,
    completed: 0,
    failed: 0,
    processedRecords: 0,
    logs: [],
    running: true,
    selected: 0,
    follow: true,
  };
}

export function reducer(state: RunState, action: Action): RunState {
  switch (action.kind) {
    case "reset":
      return initFromMeta(action.meta);
    case "select":
      return { ...state, selected: action.i, follow: false };
    case "follow":
      return { ...state, follow: action.on };
    case "event":
      return applyEvent(state, action.ev);
    default:
      return state;
  }
}

function applyEvent(state: RunState, ev: StreamEvent): RunState {
  switch (ev.type) {
    case "tick":
      return { ...state, T: ev.t };
    case "done":
      return { ...state, running: false, T: state.end };
    case "span-start": {
      const files = state.files.slice();
      const f = { ...files[ev.fi] };
      f.status = "processing";
      f.agents = f.agents.slice();
      f.agents[ev.ai] = { ...f.agents[ev.ai], status: "running" };
      files[ev.fi] = f;
      return { ...state, files, selected: state.follow ? ev.fi : state.selected };
    }
    case "span-end": {
      const files = state.files.slice();
      const f = { ...files[ev.fi] };
      f.agents = f.agents.slice();
      f.agents[ev.ai] = { ...f.agents[ev.ai], status: ev.status, detail: ev.detail, level: ev.status === "done" ? "info" : ev.status };
      let tokens = state.tokens;
      if (ev.tokens) {
        f.tokens += ev.tokens;
        tokens += ev.tokens;
      }
      files[ev.fi] = f;
      return { ...state, files, tokens };
    }
    case "file-end": {
      const files = state.files.slice();
      files[ev.fi] = { ...files[ev.fi], status: ev.status };
      return {
        ...state,
        files,
        completed: state.completed + (ev.status === "done" ? 1 : 0),
        failed: state.failed + (ev.status === "failed" ? 1 : 0),
        processedRecords: state.processedRecords + ev.records,
      };
    }
    case "log": {
      const logs = state.logs.length >= 200 ? state.logs.slice(1) : state.logs.slice();
      logs.push({ t: ev.t, agent: ev.agent, file: ev.file, level: ev.level, msg: ev.msg });
      return { ...state, logs };
    }
    default:
      return state;
  }
}
