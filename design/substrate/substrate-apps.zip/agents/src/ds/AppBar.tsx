import { NAV_LINKS, type AppId } from "./appLinks";
import { ThemeToggle } from "./theme";

/* The sticky application bar shared by every app. `active` highlights the
   current app; `extra` lets a page slot in a status chip (e.g. "tailwind v4").
   `maxW` matches each page's content width. */
export function AppBar({
  active,
  maxW = "max-w-[1480px]",
  extra,
}: {
  active: AppId;
  maxW?: string;
  extra?: React.ReactNode;
}) {
  const system = NAV_LINKS.filter((l) => l.group === "system");
  const pipeline = NAV_LINKS.filter((l) => l.group === "pipeline");

  const linkCls = (id: AppId) =>
    id === active
      ? "rounded px-2 py-1 font-medium text-fg hover:bg-hover"
      : "rounded px-2 py-1 text-fg-muted hover:bg-hover hover:text-fg";

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-surface-raised/90 backdrop-blur">
      <div className={`mx-auto flex h-12 ${maxW} items-center gap-4 px-4`}>
        <a href={NAV_LINKS[0].href} className="flex items-center gap-2 font-semibold text-fg">
          <span className="grid size-6 place-items-center rounded bg-accent text-fg-on-accent text-2xs font-bold tracking-tight">
            DC
          </span>
          <span>Substrate</span>
          <span className="hidden font-normal text-fg-subtle sm:inline">/ Design System</span>
        </a>
        <nav className="ml-3 hidden items-center gap-0.5 text-sm lg:flex">
          {system.map((l) => (
            <a key={l.id} href={l.href} className={linkCls(l.id)}>
              {l.label}
            </a>
          ))}
          <span className="mx-1 h-4 w-px bg-border" />
          {pipeline.map((l) => (
            <a key={l.id} href={l.href} className={linkCls(l.id)}>
              {l.label}
            </a>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          {extra}
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}

export function Footer({
  maxW = "max-w-[1480px]",
  children,
}: {
  maxW?: string;
  children?: React.ReactNode;
}) {
  return (
    <footer className="border-t border-border bg-surface-sunken">
      <div className={`mx-auto flex ${maxW} items-center gap-2 px-4 py-6 text-sm text-fg-muted`}>
        <span className="grid size-5 place-items-center rounded bg-accent text-fg-on-accent text-2xs font-bold">
          DC
        </span>
        <span className="font-semibold text-fg">Substrate</span>
        {children}
      </div>
    </footer>
  );
}
