import type { ButtonHTMLAttributes, ReactNode } from "react";

/* =============================================================================
   Primitives — small, semantic building blocks composed from utilities.
   Tone class strings are written out in full (never concatenated from
   fragments) so Tailwind v4's source scanner picks them up.
   ========================================================================== */

export type Tone = "info" | "success" | "warning" | "danger" | "neutral" | "accent";

const STATUS_TONE: Record<Tone, string> = {
  info: "border-info-border bg-info-bg text-info",
  success: "border-success-border bg-success-bg text-success",
  warning: "border-warning-border bg-warning-bg text-warning",
  danger: "border-danger-border bg-danger-bg text-danger",
  neutral: "border-border bg-surface-sunken text-fg-subtle",
  accent: "border-accent-border bg-accent-muted text-accent",
};

const PIP_TONE: Record<Tone, string> = {
  info: "bg-info",
  success: "bg-success",
  warning: "bg-warning",
  danger: "bg-danger",
  neutral: "bg-gray-400",
  accent: "bg-accent",
};

/** Uppercase status chip with an optional (optionally live-pulsing) pip. */
export function StatusBadge({
  tone,
  children,
  pip = true,
  live = false,
}: {
  tone: Tone;
  children: ReactNode;
  pip?: boolean;
  live?: boolean;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-sm border px-1.5 py-0.5 text-2xs font-medium ${STATUS_TONE[tone]}`}
    >
      {pip && <span className={`size-1.5 rounded-full ${PIP_TONE[tone]} ${live ? "ds-live" : ""}`} />}
      {children}
    </span>
  );
}

export type ButtonVariant = "accent" | "secondary" | "ghost" | "danger";

const BTN_VARIANT: Record<ButtonVariant, string> = {
  accent: "bg-accent text-fg-on-accent hover:bg-accent-hover",
  secondary: "border border-border bg-surface text-fg hover:bg-hover",
  ghost: "text-fg-muted hover:bg-hover hover:text-fg",
  danger: "border border-danger-border bg-danger-bg text-danger hover:bg-danger-bg/70",
};

export function Button({
  variant = "accent",
  size = "md",
  className = "",
  children,
  ...rest
}: {
  variant?: ButtonVariant;
  size?: "sm" | "md";
} & ButtonHTMLAttributes<HTMLButtonElement>) {
  const sizeCls = size === "sm" ? "px-2.5 py-1 text-xs" : "px-3 py-1.5 text-sm";
  const disabledCls = rest.disabled
    ? "cursor-not-allowed bg-disabled-bg text-disabled-fg hover:bg-disabled-bg"
    : BTN_VARIANT[variant];
  return (
    <button
      {...rest}
      className={`inline-flex items-center gap-1.5 rounded-md font-medium ${sizeCls} ${disabledCls} ${className}`}
    >
      {children}
    </button>
  );
}

/** Bordered card with optional header (title + right-slot). */
export function Card({
  title,
  right,
  children,
  className = "",
  bodyClassName = "px-3 py-2.5",
}: {
  title?: ReactNode;
  right?: ReactNode;
  children?: ReactNode;
  className?: string;
  bodyClassName?: string;
}) {
  return (
    <div className={`rounded-lg border border-border bg-surface-raised shadow-sm ${className}`}>
      {(title || right) && (
        <div className="flex items-center justify-between border-b border-border px-3 py-2">
          {typeof title === "string" ? (
            <h2 className="text-sm font-semibold text-fg">{title}</h2>
          ) : (
            title
          )}
          {right}
        </div>
      )}
      {children !== undefined && <div className={bodyClassName}>{children}</div>}
    </div>
  );
}

/** Thin progress bar. `tone` colors the fill. */
export function ProgressBar({
  value,
  tone = "accent",
  className = "h-1",
}: {
  value: number;
  tone?: "accent" | "success" | "danger" | "warning";
  className?: string;
}) {
  const fill =
    tone === "success"
      ? "bg-success"
      : tone === "danger"
        ? "bg-danger"
        : tone === "warning"
          ? "bg-warning"
          : "bg-accent";
  return (
    <div className={`overflow-hidden rounded-full bg-surface-inset ${className}`}>
      <div
        className={`h-full rounded-full ${fill} transition-[width] duration-200 ease-out`}
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
    </div>
  );
}

export interface KpiCell {
  label: ReactNode;
  value: ReactNode;
  valueClass?: string;
}

/** Bordered KPI strip — cells separated by a 1px border via gap-px trick. */
export function KpiStrip({ cells, cols = "grid-cols-2 sm:grid-cols-3 lg:grid-cols-6" }: {
  cells: KpiCell[];
  cols?: string;
}) {
  return (
    <div className={`grid ${cols} gap-px overflow-hidden rounded-lg border border-border bg-border`}>
      {cells.map((c, i) => (
        <div key={i} className="bg-surface-raised px-3 py-2.5">
          <dt className="text-2xs font-mono uppercase tracking-wide text-fg-subtle">{c.label}</dt>
          <dd className={`mt-0.5 text-xl font-semibold tabular-nums ${c.valueClass ?? "text-fg"}`}>
            {c.value}
          </dd>
        </div>
      ))}
    </div>
  );
}
