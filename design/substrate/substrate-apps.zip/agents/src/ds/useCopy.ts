import { useCallback, useRef, useState } from "react";

/** Copy-to-clipboard with a transient "copied" flag (resets after `ms`). */
export function useCopy(ms = 1200) {
  const [copied, setCopied] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const copy = useCallback(
    async (text: string) => {
      if (!navigator.clipboard) return;
      try {
        await navigator.clipboard.writeText(text);
        setCopied(true);
        if (timer.current) clearTimeout(timer.current);
        timer.current = setTimeout(() => setCopied(false), ms);
      } catch {
        /* ignore */
      }
    },
    [ms],
  );

  return { copied, copy };
}
