import { useCallback, useMemo, useRef, useState, type ReactNode } from "react";

/* =============================================================================
   Tree — interactive infrastructure tree ported from ds.js:
     • expand / collapse
     • roving-tabindex keyboard nav (Arrow keys, Home, End, Enter/Space)
     • native HTML drag-and-drop reorder / nest, with before|after|inside drop
       zones and an invalid state when dropping into self/descendant.
   State stays observable in the DOM (role, aria-expanded, data-depth, data-drop).
   ========================================================================== */

export interface TreeNode {
  id: string;
  label: ReactNode;
  children?: TreeNode[];
}

type Zone = "before" | "after" | "inside" | "invalid";

// ---- immutable tree helpers ----
function findNode(nodes: TreeNode[], id: string): TreeNode | null {
  for (const n of nodes) {
    if (n.id === id) return n;
    if (n.children) {
      const f = findNode(n.children, id);
      if (f) return f;
    }
  }
  return null;
}

function isDescendant(parent: TreeNode, id: string): boolean {
  if (!parent.children) return false;
  return parent.children.some((c) => c.id === id || isDescendant(c, id));
}

function removeNode(nodes: TreeNode[], id: string): [TreeNode[], TreeNode | null] {
  let removed: TreeNode | null = null;
  const walk = (list: TreeNode[]): TreeNode[] =>
    list.reduce<TreeNode[]>((acc, n) => {
      if (n.id === id) {
        removed = n;
        return acc;
      }
      acc.push(n.children ? { ...n, children: walk(n.children) } : n);
      return acc;
    }, []);
  const next = walk(nodes);
  return [next, removed];
}

function insertNode(
  nodes: TreeNode[],
  targetId: string,
  zone: Zone,
  node: TreeNode,
): TreeNode[] {
  const walk = (list: TreeNode[]): TreeNode[] => {
    const out: TreeNode[] = [];
    for (const n of list) {
      if (n.id === targetId && (zone === "before" || zone === "after")) {
        if (zone === "before") out.push(node);
        out.push(n.children ? { ...n, children: walk(n.children) } : n);
        if (zone === "after") out.push(node);
      } else if (n.id === targetId && zone === "inside") {
        out.push({ ...n, children: [...(n.children ?? []), node] });
      } else {
        out.push(n.children ? { ...n, children: walk(n.children) } : n);
      }
    }
    return out;
  };
  return walk(nodes);
}

export function Tree({ data }: { data: TreeNode[] }) {
  const [nodes, setNodes] = useState<TreeNode[]>(data);
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [focusId, setFocusId] = useState<string | null>(nodes[0]?.id ?? null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [drop, setDrop] = useState<{ id: string; zone: Zone } | null>(null);
  const rowRefs = useRef<Map<string, HTMLDivElement>>(new Map());

  const isExpanded = (id: string) => !collapsed.has(id);
  const toggle = (id: string) =>
    setCollapsed((s) => {
      const next = new Set(s);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  const setExpanded = (id: string, open: boolean) =>
    setCollapsed((s) => {
      const next = new Set(s);
      open ? next.delete(id) : next.add(id);
      return next;
    });

  // flatten visible items (respecting collapse) for keyboard nav
  const visible = useMemo(() => {
    const out: { id: string; depth: number; hasChildren: boolean }[] = [];
    const walk = (list: TreeNode[], depth: number) => {
      for (const n of list) {
        const hasChildren = !!n.children?.length;
        out.push({ id: n.id, depth, hasChildren });
        if (hasChildren && isExpanded(n.id)) walk(n.children!, depth + 1);
      }
    };
    walk(nodes, 0);
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nodes, collapsed]);

  const focusRow = useCallback((id: string) => {
    setFocusId(id);
    rowRefs.current.get(id)?.focus();
  }, []);

  const onKeyDown = (e: React.KeyboardEvent, id: string) => {
    const i = visible.findIndex((v) => v.id === id);
    if (i < 0) return;
    const item = visible[i];
    let handled = true;
    switch (e.key) {
      case "ArrowDown":
        if (i < visible.length - 1) focusRow(visible[i + 1].id);
        break;
      case "ArrowUp":
        if (i > 0) focusRow(visible[i - 1].id);
        break;
      case "ArrowRight":
        if (item.hasChildren && !isExpanded(id)) setExpanded(id, true);
        else if (item.hasChildren && i < visible.length - 1) focusRow(visible[i + 1].id);
        break;
      case "ArrowLeft":
        if (item.hasChildren && isExpanded(id)) setExpanded(id, false);
        else {
          for (let j = i - 1; j >= 0; j--)
            if (visible[j].depth < item.depth) {
              focusRow(visible[j].id);
              break;
            }
        }
        break;
      case "Enter":
      case " ":
        if (item.hasChildren) toggle(id);
        break;
      case "Home":
        if (visible[0]) focusRow(visible[0].id);
        break;
      case "End":
        if (visible.length) focusRow(visible[visible.length - 1].id);
        break;
      default:
        handled = false;
    }
    if (handled) e.preventDefault();
  };

  // ---- drag and drop ----
  const onDragOver = (e: React.DragEvent, id: string) => {
    if (!dragId) return;
    e.preventDefault();
    const dragged = findNode(nodes, dragId);
    if (!dragged) return;
    if (id === dragId || isDescendant(dragged, id)) {
      setDrop({ id, zone: "invalid" });
      e.dataTransfer.dropEffect = "none";
      return;
    }
    e.dataTransfer.dropEffect = "move";
    const row = rowRefs.current.get(id);
    if (!row) return;
    const r = row.getBoundingClientRect();
    const rel = (e.clientY - r.top) / r.height;
    const zone: Zone = rel < 0.3 ? "before" : rel > 0.7 ? "after" : "inside";
    setDrop({ id, zone });
  };

  const onDrop = (e: React.DragEvent, id: string) => {
    if (!dragId || !drop) return;
    e.preventDefault();
    const { zone } = drop;
    if (zone !== "invalid" && id !== dragId) {
      const dragged = findNode(nodes, dragId);
      if (dragged && !isDescendant(dragged, id)) {
        const [without, removed] = removeNode(nodes, dragId);
        if (removed) {
          setNodes(insertNode(without, id, zone, removed));
          if (zone === "inside") setExpanded(id, true);
        }
      }
    }
    setDrop(null);
    setDragId(null);
  };

  const renderList = (list: TreeNode[], depth: number): ReactNode => (
    <ul role={depth === 0 ? "tree" : "group"}>
      {list.map((n) => {
        const hasChildren = !!n.children?.length;
        const expanded = isExpanded(n.id);
        const isDropTarget = drop?.id === n.id;
        return (
          <li
            key={n.id}
            role="treeitem"
            aria-expanded={hasChildren ? expanded : undefined}
            data-depth={depth}
            data-drop={isDropTarget ? drop!.zone : undefined}
          >
            <div
              ref={(el) => {
                if (el) rowRefs.current.set(n.id, el);
                else rowRefs.current.delete(n.id);
              }}
              className={`ds-tree-row flex items-center gap-1 rounded-sm px-1.5 py-1 text-sm hover:bg-hover ${
                dragId === n.id ? "ds-dragging" : ""
              }`}
              tabIndex={focusId === n.id ? 0 : -1}
              onFocus={() => setFocusId(n.id)}
              onKeyDown={(e) => onKeyDown(e, n.id)}
              onDragOver={(e) => onDragOver(e, n.id)}
              onDrop={(e) => onDrop(e, n.id)}
              aria-grabbed={dragId === n.id ? true : undefined}
            >
              <button
                type="button"
                aria-label={hasChildren ? (expanded ? "Collapse" : "Expand") : undefined}
                onClick={() => hasChildren && toggle(n.id)}
                className="ds-chev grid size-4 shrink-0 place-items-center"
                tabIndex={-1}
              >
                ▶
              </button>
              <span
                className="ds-drag-handle shrink-0 select-none px-0.5 text-fg-subtle"
                draggable
                onDragStart={(e) => {
                  setDragId(n.id);
                  e.dataTransfer.effectAllowed = "move";
                  try {
                    e.dataTransfer.setData("text/plain", n.id);
                  } catch {
                    /* ignore */
                  }
                }}
                onDragEnd={() => {
                  setDragId(null);
                  setDrop(null);
                }}
                aria-hidden="true"
              >
                ⠿
              </span>
              <span className="min-w-0 flex-1 truncate text-fg">{n.label}</span>
            </div>
            {hasChildren && expanded && renderList(n.children!, depth + 1)}
          </li>
        );
      })}
    </ul>
  );

  return <div data-tree>{renderList(nodes, 0)}</div>;
}
