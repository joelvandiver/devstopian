import { useMemo, useState, type ReactNode } from "react";

/* =============================================================================
   DataTable — condensed table with sortable headers, sticky header/first col,
   zebra striping, truncation, and compact/default/comfortable density.
   The sort comparison is ported from ds.js (numeric when both sides parse as
   numbers, otherwise a locale/numeric-aware string compare).
   ========================================================================== */

export type Density = "compact" | "default" | "comfortable";
export type SortType = "auto" | "number" | "string";

export interface Column<T> {
  key: string;
  header: ReactNode;
  align?: "left" | "right";
  sortable?: boolean;
  sortType?: SortType;
  sticky?: boolean;
  render: (row: T) => ReactNode;
  /** raw value used for sorting; defaults to render output if a primitive */
  sortValue?: (row: T) => string | number;
  cellClass?: string;
  headerClass?: string;
}

type Dir = "ascending" | "descending" | "none";

function numericize(s: string | number): number | null {
  const n = parseFloat(String(s).replace(/[^0-9.\-]/g, ""));
  return isNaN(n) ? null : n;
}

export function DataTable<T>({
  columns,
  rows,
  density = "default",
  zebra = true,
  getRowKey,
  className = "",
}: {
  columns: Column<T>[];
  rows: T[];
  density?: Density;
  zebra?: boolean;
  getRowKey?: (row: T, i: number) => string | number;
  className?: string;
}) {
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [dir, setDir] = useState<Dir>("none");

  const sorted = useMemo(() => {
    if (!sortKey || dir === "none") return rows;
    const col = columns.find((c) => c.key === sortKey);
    if (!col) return rows;
    const val = (r: T): string | number =>
      col.sortValue ? col.sortValue(r) : (col.render(r) as unknown as string);
    const type = col.sortType ?? "auto";
    const out = [...rows].sort((a, b) => {
      const av = val(a);
      const bv = val(b);
      const an = numericize(av);
      const bn = numericize(bv);
      let cmp: number;
      if (type === "number" || (type === "auto" && an !== null && bn !== null)) {
        cmp = (an ?? 0) - (bn ?? 0);
      } else {
        cmp = String(av).localeCompare(String(bv), undefined, {
          numeric: true,
          sensitivity: "base",
        });
      }
      return dir === "ascending" ? cmp : -cmp;
    });
    return out;
  }, [rows, columns, sortKey, dir]);

  function onSort(col: Column<T>) {
    if (!col.sortable) return;
    if (sortKey !== col.key) {
      setSortKey(col.key);
      setDir("ascending");
    } else {
      setDir(dir === "ascending" ? "descending" : "ascending");
    }
  }

  return (
    <div className={`overflow-auto rounded border border-border ${className}`}>
      <table className="ds-table w-full text-left text-xs" data-density={density}>
        <thead className="bg-surface-sunken text-fg-muted">
          <tr>
            {columns.map((col) => {
              const ariaSort: Dir | undefined = col.sortable
                ? sortKey === col.key
                  ? dir
                  : "none"
                : undefined;
              return (
                <th
                  key={col.key}
                  aria-sort={ariaSort}
                  data-sort-type={col.sortType}
                  data-sticky-col={col.sticky ? "" : undefined}
                  onClick={() => onSort(col)}
                  className={`font-medium ${col.align === "right" ? "text-right" : ""} ${
                    col.sticky ? "bg-surface-sunken" : ""
                  } ${col.headerClass ?? ""}`}
                >
                  <span className="inline-flex items-center gap-1">
                    {col.header}
                    {col.sortable && <span className="ds-caret" aria-hidden="true" />}
                  </span>
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {sorted.map((row, i) => (
            <tr
              key={getRowKey ? getRowKey(row, i) : i}
              className={zebra && i % 2 === 1 ? "bg-surface-sunken" : ""}
            >
              {columns.map((col) => (
                <td
                  key={col.key}
                  data-sticky-col={col.sticky ? "" : undefined}
                  className={`${col.align === "right" ? "text-right" : ""} ${
                    col.sticky ? "bg-surface-raised" : ""
                  } ${col.cellClass ?? ""}`}
                >
                  {col.render(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
