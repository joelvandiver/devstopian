import { useCallback, useRef, useState, type ReactNode } from "react";

export type ToastKind = "success" | "info" | "neutral";

export interface ToastMsg {
  message: ReactNode;
  kind?: ToastKind;
  action?: ReactNode;
  /** ms before auto-dismiss */
  duration?: number;
}

const KIND_CLS: Record<ToastKind, string> = {
  success: "border-success-border bg-success-bg text-success",
  info: "border-info-border bg-info-bg text-info",
  neutral: "border-border bg-surface-overlay text-fg",
};

/** Bottom-center toast + a `show()` helper. Render <Toast/> once near the root. */
export function useToast() {
  const [msg, setMsg] = useState<ToastMsg | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const show = useCallback((m: ToastMsg) => {
    setMsg(m);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setMsg(null), m.duration ?? 3200);
  }, []);

  const node = msg ? (
    <div className="fixed bottom-4 left-1/2 z-[60] -translate-x-1/2">
      <div
        className={`flex items-center gap-3 rounded-lg border px-3.5 py-2 text-sm font-medium shadow-overlay ${KIND_CLS[msg.kind ?? "neutral"]}`}
      >
        <span>{msg.message}</span>
        {msg.action}
      </div>
    </div>
  ) : null;

  return { show, node };
}
