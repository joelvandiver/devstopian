/* =============================================================================
   Cross-app navigation.
   The five apps are independent builds. When served side-by-side under one
   parent (…/substrate/<app>/) the relative links below resolve to each sibling
   app — mirroring how the original *.html demos interlinked. Override the base
   at build time with VITE_APP_BASE (e.g. an absolute origin) if hosting apart.
   ========================================================================== */

export type AppId =
  | "design-guide"
  | "upload"
  | "agents"
  | "promote"
  | "download";

const BASE = import.meta.env.VITE_APP_BASE ?? "..";

function href(id: AppId): string {
  // design-guide is the "Overview" root
  return `${BASE}/${id}/`;
}

export interface NavLink {
  id: AppId;
  label: string;
  href: string;
  group: "system" | "pipeline";
}

export const NAV_LINKS: NavLink[] = [
  { id: "design-guide", label: "Overview", href: href("design-guide"), group: "system" },
  { id: "upload", label: "Upload", href: href("upload"), group: "pipeline" },
  { id: "agents", label: "Agents", href: href("agents"), group: "pipeline" },
  { id: "promote", label: "Promote", href: href("promote"), group: "pipeline" },
  { id: "download", label: "Download", href: href("download"), group: "pipeline" },
];

export const appHref = href;
