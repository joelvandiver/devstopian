import { appHref, type AppId } from "./appLinks";

const STAGES: { id: AppId; label: string }[] = [
  { id: "upload", label: "Upload" },
  { id: "agents", label: "Agents" },
  { id: "promote", label: "Promote" },
  { id: "download", label: "Download" },
];

/* The pipeline stage breadcrumb used by Promote & Download. Stages before the
   active one read as done (✓), the active one is highlighted. */
export function PipelineBreadcrumb({ active }: { active: AppId }) {
  const activeIdx = STAGES.findIndex((s) => s.id === active);
  return (
    <nav className="mb-3 flex items-center gap-1.5 text-2xs font-mono" aria-label="Pipeline stage">
      {STAGES.map((s, i) => {
        const done = i < activeIdx;
        const isActive = i === activeIdx;
        return (
          <span key={s.id} className="flex items-center gap-1.5">
            {isActive ? (
              <span className="inline-flex items-center gap-1 rounded-sm border border-accent-border bg-accent-muted px-1.5 py-0.5 font-medium text-accent">
                ● {s.label}
              </span>
            ) : (
              <a
                href={appHref(s.id)}
                className="inline-flex items-center gap-1 rounded-sm px-1.5 py-0.5 text-fg-subtle hover:bg-hover hover:text-fg"
              >
                {done && <span className="text-success">✓</span>} {s.label}
              </a>
            )}
            {i < STAGES.length - 1 && <span className="text-fg-subtle">→</span>}
          </span>
        );
      })}
    </nav>
  );
}
