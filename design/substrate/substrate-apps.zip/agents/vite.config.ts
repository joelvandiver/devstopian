import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

// Each Substrate app is an independent Vite project. `base: "./"` keeps asset
// URLs relative so the built apps can be served side-by-side under one parent.
export default defineConfig({
  base: "./",
  plugins: [react(), tailwindcss()],
  server: { port: 5173 },
});
