import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { Contact, FieldStatus, Model, Source } from "../ds/model";
import type { Survey } from "../api/handlers";

async function getJSON<T>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${res.status} ${url}`);
  return res.json() as Promise<T>;
}

async function send<T>(url: string, method: string, body?: unknown): Promise<T> {
  const res = await fetch(url, {
    method,
    headers: body ? { "content-type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw new Error(`${res.status} ${url}`);
  return res.json() as Promise<T>;
}

export function useModel() {
  return useQuery({ queryKey: ["model"], queryFn: () => getJSON<Model>("/api/model") });
}
export function useContacts() {
  return useQuery({ queryKey: ["contacts"], queryFn: () => getJSON<Contact[]>("/api/contacts") });
}
export function useSurveys() {
  return useQuery({ queryKey: ["surveys"], queryFn: () => getJSON<Survey[]>("/api/surveys") });
}

export interface FieldPatch {
  eid: string;
  key: string;
  value?: string;
  status?: FieldStatus;
  source?: Source;
  confidence?: number;
}

export function usePatchField() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ eid, key, ...body }: FieldPatch) =>
      send<Model>(`/api/model/entities/${eid}/fields/${key}`, "PATCH", body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["model"] }),
  });
}

export function useSendSurvey() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: {
      recipientId: string;
      title: string;
      items: { entityId: string; fieldKey: string; question: string }[];
    }) => send<Survey>("/api/surveys", "POST", body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["model"] });
      qc.invalidateQueries({ queryKey: ["surveys"] });
    },
  });
}

export function useRespondSurvey() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => send<Survey>(`/api/surveys/${id}/respond`, "POST"),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["model"] });
      qc.invalidateQueries({ queryKey: ["surveys"] });
    },
  });
}

export function usePromote() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => send<{ open: number }>("/api/model/promote", "POST"),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["model"] }),
  });
}
