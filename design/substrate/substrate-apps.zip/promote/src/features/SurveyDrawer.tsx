import { useEffect, useState } from "react";
import { Drawer } from "../ds";
import type { Contact, Model } from "../ds/model";

export interface CartItem {
  entityId: string;
  fieldKey: string;
}

/* Builds a customer survey from the flagged gap fields, mirroring the promotion
   drawer: pick a recipient, edit auto-drafted questions, send. */
export function SurveyDrawer({
  open,
  onClose,
  cart,
  model,
  contacts,
  onSend,
}: {
  open: boolean;
  onClose: () => void;
  cart: CartItem[];
  model: Model;
  contacts: Contact[];
  onSend: (recipientId: string, title: string, questions: string[]) => void;
}) {
  const field = (eid: string, key: string) =>
    model.entities.find((e) => e.id === eid)?.fields.find((f) => f.key === key);
  const entity = (eid: string) => model.entities.find((e) => e.id === eid);

  const defaultQuestions = cart.map((c) => {
    const f = field(c.entityId, c.fieldKey);
    const e = entity(c.entityId);
    return f && e
      ? `What is the ${f.label.toLowerCase()} for ${e.type.toLowerCase()} ${e.label}?`
      : "";
  });

  const [questions, setQuestions] = useState<string[]>(defaultQuestions);
  const [recipientId, setRecipientId] = useState(contacts[0]?.id ?? "");
  const [title, setTitle] = useState(
    "Fleet data request · " + new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" }),
  );

  // re-seed questions whenever the drawer opens with a new cart
  useEffect(() => {
    if (open) {
      setQuestions(defaultQuestions);
      setRecipientId(contacts[0]?.id ?? "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  return (
    <Drawer open={open} onClose={onClose} label="Build survey">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div>
          <h2 className="text-md font-semibold text-fg">New customer survey</h2>
          <p className="text-xs text-fg-muted">
            Auto-drafted from <span className="font-medium text-fg">{cart.length}</span> gap fields.
          </p>
        </div>
        <button onClick={onClose} aria-label="Close" className="rounded p-1 text-fg-subtle hover:bg-hover hover:text-fg">
          ✕
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-3">
        <label className="block">
          <span className="mb-1 block text-xs font-medium text-fg-muted">Send to</span>
          <select
            value={recipientId}
            onChange={(e) => setRecipientId(e.target.value)}
            className="w-full rounded-md border border-border bg-surface px-2.5 py-1.5 text-sm text-fg focus:border-accent focus:outline-none focus:ring-2 focus:ring-ring/40"
          >
            {contacts.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} — {c.role}, {c.org}
              </option>
            ))}
          </select>
        </label>
        <label className="mt-3 block">
          <span className="mb-1 block text-xs font-medium text-fg-muted">Survey title</span>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full rounded-md border border-border bg-surface px-2.5 py-1.5 text-sm text-fg focus:border-accent focus:outline-none focus:ring-2 focus:ring-ring/40"
          />
        </label>
        <p className="mt-4 mb-2 text-2xs font-mono uppercase tracking-wide text-fg-subtle">Questions</p>
        <ol className="space-y-2">
          {cart.map((c, i) => {
            const f = field(c.entityId, c.fieldKey);
            const e = entity(c.entityId);
            return (
              <li key={`${c.entityId}.${c.fieldKey}`} className="rounded-md border border-border bg-surface px-2.5 py-2">
                <div className="mb-1 flex items-center gap-1.5">
                  <span className="grid size-4 place-items-center rounded-full bg-accent-muted font-mono text-2xs text-accent">
                    {i + 1}
                  </span>
                  <span className="font-mono text-2xs text-fg-subtle">
                    {e?.label} · {f?.key}
                  </span>
                </div>
                <input
                  type="text"
                  value={questions[i] ?? ""}
                  onChange={(ev) =>
                    setQuestions((qs) => qs.map((q, j) => (j === i ? ev.target.value : q)))
                  }
                  className="w-full rounded border border-border bg-surface-sunken px-2 py-1 text-sm text-fg focus:border-accent focus:outline-none focus:ring-2 focus:ring-ring/40"
                />
              </li>
            );
          })}
        </ol>
      </div>

      <div className="flex items-center gap-2 border-t border-border px-4 py-3">
        <span className="font-mono text-2xs text-fg-subtle">{cart.length} questions</span>
        <button
          onClick={() => onSend(recipientId, title, questions)}
          className="ml-auto inline-flex items-center gap-1.5 rounded-md bg-accent px-3.5 py-2 text-sm font-medium text-fg-on-accent hover:bg-accent-hover"
        >
          Send survey
        </button>
      </div>
    </Drawer>
  );
}
