import { useState } from "react";
import {
  appHref,
  PipelineBreadcrumb,
  StatusBadge,
  useToast,
  type Tone,
} from "../ds";
import { counts, completeness, type Entity, type Field, type FieldStatus } from "../ds/model";
import {
  useContacts,
  useModel,
  usePatchField,
  usePromote,
  useRespondSurvey,
  useSendSurvey,
  useSurveys,
} from "./api";
import { SurveyDrawer, type CartItem } from "./SurveyDrawer";

const STATUS_TONE: Record<FieldStatus, { tone: Tone; label: string; pip: boolean; live?: boolean }> = {
  confirmed: { tone: "success", label: "CONFIRMED", pip: false },
  review: { tone: "warning", label: "REVIEW", pip: false },
  conflict: { tone: "danger", label: "CONFLICT", pip: false },
  gap: { tone: "neutral", label: "GAP", pip: false },
  awaiting: { tone: "info", label: "AWAITING", pip: true, live: true },
};

function Badge({ status }: { status: FieldStatus }) {
  const s = STATUS_TONE[status];
  return (
    <StatusBadge tone={s.tone} pip={s.pip} live={s.live}>
      {s.label}
    </StatusBadge>
  );
}

function Confidence({ c }: { c: number }) {
  if (!c) return <span className="font-mono text-2xs text-fg-subtle">—</span>;
  const col = c >= 0.8 ? "bg-success" : c >= 0.55 ? "bg-warning" : "bg-danger";
  return (
    <span className="inline-flex items-center gap-1" title={`confidence ${Math.round(c * 100)}%`}>
      <span className="h-1 w-8 overflow-hidden rounded-full bg-surface-inset">
        <span className={`block h-full ${col}`} style={{ width: `${Math.round(c * 100)}%` }} />
      </span>
      <span className="font-mono text-2xs text-fg-subtle">{Math.round(c * 100)}</span>
    </span>
  );
}

const shortFile = (f: string) => (f.length > 16 ? f.slice(0, 14) + "…" : f);

function SourceChip({ file, agent }: { file: string | null; agent: string }) {
  const glyph = agent === "human" ? "✎" : agent === "survey" ? "✉" : "◈";
  return (
    <span
      className="inline-flex items-center gap-1 rounded-sm border border-border bg-surface px-1.5 py-0.5 font-mono text-2xs text-fg-muted"
      title={`${file ?? ""} · ${agent}`}
    >
      <span className="text-fg-subtle">{glyph}</span>
      {file ? shortFile(file) : agent}
    </span>
  );
}

export function PromoteView() {
  const { data: model } = useModel();
  const { data: contacts = [] } = useContacts();
  const { data: surveys = [] } = useSurveys();
  const patch = usePatchField();
  const sendSurvey = useSendSurvey();
  const respond = useRespondSurvey();
  const promote = usePromote();
  const { show, node: toastNode } = useToast();

  const [sel, setSel] = useState<string | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [drawer, setDrawer] = useState(false);

  if (!model) return <main className="mx-auto max-w-[1600px] px-4 py-10 text-sm text-fg-muted">Loading model…</main>;

  const selId = sel ?? model.entities[0].id;
  const selEntity = model.entities.find((e) => e.id === selId)!;
  const c = counts(model);
  const pct = completeness(model);
  const inCart = (eid: string, key: string) => cart.some((x) => x.entityId === eid && x.fieldKey === key);

  const commitValue = (eid: string, key: string, value: string) => {
    if (value.trim() === "") return;
    patch.mutate({ eid, key, value: value.trim(), status: "confirmed", source: { file: null, agent: "human", confidence: 1 }, confidence: 1 });
    setCart((cs) => cs.filter((x) => !(x.entityId === eid && x.fieldKey === key)));
  };

  function ValueEditor({ f }: { f: Field }) {
    if (f.status === "conflict") {
      return (
        <div>
          <p className="mb-1 text-2xs text-danger">Two sources disagree — choose one or type a value:</p>
          <div className="flex flex-wrap gap-1.5">
            {f.candidates?.map((cand, i) => (
              <button
                key={i}
                onClick={() =>
                  patch.mutate({
                    eid: selId,
                    key: f.key,
                    value: cand.value,
                    status: "confirmed",
                    source: { file: cand.source.file, agent: cand.source.agent, confidence: 1 },
                    confidence: 1,
                  })
                }
                className="inline-flex items-center gap-1.5 rounded-md border border-danger-border bg-danger-bg px-2 py-1 text-sm text-fg hover:border-accent hover:bg-accent-muted"
              >
                <span className="font-medium">{cand.value}</span>
                <span className="font-mono text-2xs text-fg-subtle">{shortFile(cand.source.file)}</span>
              </button>
            ))}
          </div>
          <input
            type="text"
            placeholder="or enter the correct value"
            onKeyDown={(e) => e.key === "Enter" && commitValue(selId, f.key, (e.target as HTMLInputElement).value)}
            onBlur={(e) => commitValue(selId, f.key, e.target.value)}
            className="mt-1.5 w-full rounded-md border border-border bg-surface px-2 py-1 text-sm text-fg placeholder:text-fg-subtle focus:border-accent focus:outline-none focus:ring-2 focus:ring-ring/40"
          />
        </div>
      );
    }
    if (f.status === "gap") {
      return (
        <input
          type="text"
          placeholder="— missing —"
          onKeyDown={(e) => e.key === "Enter" && commitValue(selId, f.key, (e.target as HTMLInputElement).value)}
          onBlur={(e) => commitValue(selId, f.key, e.target.value)}
          className="w-full rounded-md border border-dashed border-border bg-surface-sunken px-2 py-1 text-sm text-fg placeholder:text-fg-subtle focus:border-accent focus:bg-surface focus:outline-none focus:ring-2 focus:ring-ring/40"
        />
      );
    }
    if (f.status === "awaiting") {
      return (
        <input
          type="text"
          placeholder="awaiting customer response…"
          disabled
          className="w-full cursor-not-allowed rounded-md border border-info-border bg-info-bg px-2 py-1 text-sm text-info/70"
        />
      );
    }
    return (
      <div>
        <input
          key={`${f.key}:${f.value}`}
          type="text"
          defaultValue={f.value}
          onKeyDown={(e) => e.key === "Enter" && commitValue(selId, f.key, (e.target as HTMLInputElement).value)}
          onBlur={(e) => e.target.value !== f.value && commitValue(selId, f.key, e.target.value)}
          className="w-full rounded-md border border-border bg-surface px-2 py-1 text-sm text-fg focus:border-accent focus:outline-none focus:ring-2 focus:ring-ring/40"
        />
        {f.unit && <span className="mt-0.5 block font-mono text-2xs text-fg-subtle">unit: {f.unit}</span>}
      </div>
    );
  }

  const openItems = model.entities.flatMap((e) =>
    e.fields.filter((f) => f.status !== "confirmed").map((f) => ({ e, f })),
  );

  const readinessParts: [string, number, string][] = [
    ["confirmed", c.confirmed, "text-success"],
    ["review", c.review, "text-warning"],
    ["conflict", c.conflict, "text-danger"],
    ["awaiting", c.awaiting, "text-info"],
    ["gap", c.gap, "text-fg-subtle"],
  ];

  return (
    <main className="mx-auto max-w-[1600px] px-4 py-5">
      <PipelineBreadcrumb active="promote" />

      {/* HEADER + READINESS */}
      <div className="mb-4 flex flex-wrap items-end justify-between gap-4 border-b border-border pb-3">
        <div className="min-w-0">
          <h1 className="text-2xl font-bold tracking-tight text-fg">Promote information model</h1>
          <p className="mt-1 max-w-2xl text-sm text-fg-muted text-pretty">
            Your uploaded files and the agents' output are mapped into the final{" "}
            <span className="font-medium text-fg">fleet information model</span> below. Review each
            field, resolve conflicts, and send customers surveys to close the gaps — then promote for
            download.
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-4">
          <div className="w-56">
            <div className="mb-1 flex items-baseline justify-between">
              <span className="text-2xs font-mono uppercase tracking-wide text-fg-subtle">Model readiness</span>
              <span className="text-sm font-semibold tabular-nums text-fg">{pct}%</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-surface-inset">
              <div className="h-full rounded-full bg-accent transition-[width] duration-300" style={{ width: `${pct}%` }} />
            </div>
            <div className="mt-1.5 flex flex-wrap gap-x-3 gap-y-0.5 text-2xs">
              {readinessParts
                .filter(([, n]) => n > 0)
                .map(([label, n, col]) => (
                  <span key={label} className={col}>
                    <span className="font-semibold tabular-nums">{n}</span> {label}
                  </span>
                ))}
            </div>
          </div>
          <button
            onClick={() =>
              promote.mutate(undefined, {
                onSuccess: (r) =>
                  show({
                    message:
                      r.open === 0
                        ? "Model promoted · 100% confirmed — ready to download"
                        : `Model promoted with ${r.open} open field${r.open === 1 ? "" : "s"} · download anytime`,
                    kind: r.open === 0 ? "success" : "info",
                    duration: 6000,
                    action: (
                      <a href={appHref("download")} className="rounded-md bg-accent px-2.5 py-1 text-xs font-medium text-fg-on-accent hover:bg-accent-hover">
                        Download →
                      </a>
                    ),
                  }),
              })
            }
            className="inline-flex items-center gap-1.5 rounded-md bg-accent px-3.5 py-2 text-sm font-medium text-fg-on-accent hover:bg-accent-hover"
          >
            Promote model →
          </button>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[250px_1fr_340px]">
        {/* ENTITY NAV */}
        <section className="rounded-lg border border-border bg-surface-raised shadow-sm">
          <div className="border-b border-border px-3 py-2">
            <h2 className="text-sm font-semibold text-fg">Model entities</h2>
          </div>
          <ul className="divide-y divide-border">
            {model.entities.map((e: Entity) => {
              const conf = e.fields.filter((f) => f.status === "confirmed").length;
              const epct = Math.round((conf / e.fields.length) * 100);
              const open = e.fields.filter((f) => f.status !== "confirmed").length;
              const on = e.id === selId;
              return (
                <li key={e.id}>
                  <button
                    onClick={() => setSel(e.id)}
                    className={`w-full px-3 py-2 text-left ${on ? "bg-selected" : "hover:bg-hover"}`}
                  >
                    <div className="flex items-center gap-2">
                      <span className={`truncate text-sm font-medium ${on ? "text-accent" : "text-fg"}`}>{e.label}</span>
                      {open ? (
                        <span className="ml-auto inline-flex items-center rounded-full bg-warning-bg px-1.5 text-2xs font-medium text-warning">
                          {open}
                        </span>
                      ) : (
                        <span className="ml-auto text-success">✓</span>
                      )}
                    </div>
                    <div className="mt-0.5 font-mono text-2xs text-fg-subtle">{e.type}</div>
                    <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-surface-inset">
                      <div className="h-full rounded-full bg-accent" style={{ width: `${epct}%` }} />
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>

        {/* FIELD EDITOR */}
        <section className="rounded-lg border border-border bg-surface-raised shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-3 py-2">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-semibold text-fg">{selEntity.label}</h2>
              <span className="inline-flex items-center rounded-sm border border-border bg-surface-sunken px-1.5 py-0.5 font-mono text-2xs text-fg-muted">
                {selEntity.type}
              </span>
            </div>
            <span className="font-mono text-2xs text-fg-subtle">{selEntity.sublabel}</span>
          </div>
          <div className="hidden items-center gap-3 border-b border-border bg-surface-sunken px-3 py-1.5 text-2xs font-mono uppercase tracking-wide text-fg-subtle md:flex">
            <span className="w-40 shrink-0">Field</span>
            <span className="min-w-[180px] flex-1">Value</span>
            <span className="w-64 shrink-0 text-right">Provenance · status</span>
          </div>
          <div className="divide-y divide-border">
            {selEntity.fields.map((f) => (
              <div key={f.key} className="flex flex-wrap items-start gap-3 px-3 py-2.5">
                <div className="w-40 shrink-0 pt-1">
                  <p className="text-sm font-medium text-fg">{f.label}</p>
                  {f.note && <p className="mt-0.5 text-2xs text-fg-subtle text-pretty">{f.note}</p>}
                </div>
                <div className="min-w-[180px] flex-1">
                  <ValueEditor f={f} />
                </div>
                <div className="flex w-64 shrink-0 flex-col items-end gap-1.5">
                  <div className="flex items-center gap-1.5">
                    {f.source && <SourceChip file={f.source.file} agent={f.source.agent} />}
                    <Confidence c={f.confidence} />
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Badge status={f.status} />
                    {(f.status === "review" || f.status === "conflict") && (
                      <button
                        onClick={() => patch.mutate({ eid: selId, key: f.key, status: "confirmed", confidence: 1 })}
                        className="rounded px-1.5 py-0.5 text-2xs font-medium text-success hover:bg-success-bg"
                      >
                        Confirm
                      </button>
                    )}
                    {f.status === "gap" &&
                      (inCart(selId, f.key) ? (
                        <span className="rounded px-1.5 py-0.5 text-2xs font-medium text-accent">In survey ✓</span>
                      ) : (
                        <button
                          onClick={() => setCart((cs) => [...cs, { entityId: selId, fieldKey: f.key }])}
                          className="rounded border border-border px-1.5 py-0.5 text-2xs font-medium text-fg-muted hover:bg-hover hover:text-fg"
                        >
                          + Survey
                        </button>
                      ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* GAPS + SURVEYS */}
        <section className="flex flex-col gap-4">
          <div className="rounded-lg border border-border bg-surface-raised shadow-sm">
            <div className="flex items-center justify-between border-b border-border px-3 py-2">
              <h2 className="text-sm font-semibold text-fg">Open items</h2>
              <span className="inline-flex items-center rounded-full bg-warning-bg px-2 py-0.5 text-2xs font-medium text-warning">
                {openItems.length}
              </span>
            </div>
            <ul className="max-h-64 divide-y divide-border overflow-y-auto">
              {openItems.length === 0 ? (
                <li className="px-3 py-6 text-center text-xs text-success">All fields confirmed ✓</li>
              ) : (
                openItems.map((it) => (
                  <li key={`${it.e.id}.${it.f.key}`}>
                    <button
                      onClick={() => setSel(it.e.id)}
                      className="flex w-full items-center gap-2 px-3 py-1.5 text-left hover:bg-hover"
                    >
                      <span className="min-w-0 flex-1">
                        <span className="truncate text-xs font-medium text-fg">{it.f.label}</span>
                        <span className="ml-1 font-mono text-2xs text-fg-subtle">{it.e.label}</span>
                      </span>
                      <Badge status={it.f.status} />
                    </button>
                  </li>
                ))
              )}
            </ul>
          </div>

          {/* survey cart */}
          <div className="rounded-lg border border-border bg-surface-raised shadow-sm">
            <div className="flex items-center justify-between border-b border-border px-3 py-2">
              <h2 className="text-sm font-semibold text-fg">Customer survey</h2>
              <span className="inline-flex items-center rounded-full bg-accent-muted px-2 py-0.5 text-2xs font-medium text-accent">
                {cart.length} {cart.length === 1 ? "field" : "fields"}
              </span>
            </div>
            {cart.length === 0 ? (
              <div className="px-3 py-6 text-center text-xs text-fg-subtle">
                Flag gap fields with <span className="font-medium text-fg">Survey</span> to build a questionnaire for your customer.
              </div>
            ) : (
              <ul className="divide-y divide-border">
                {cart.map((c2) => {
                  const e = model.entities.find((x) => x.id === c2.entityId)!;
                  const f = e.fields.find((x) => x.key === c2.fieldKey)!;
                  return (
                    <li key={`${c2.entityId}.${c2.fieldKey}`} className="flex items-center gap-2 px-3 py-1.5">
                      <span className="min-w-0 flex-1">
                        <span className="text-xs font-medium text-fg">{f.label}</span>
                        <span className="ml-1 font-mono text-2xs text-fg-subtle">{e.label}</span>
                      </span>
                      <button
                        onClick={() => setCart((cs) => cs.filter((x) => !(x.entityId === c2.entityId && x.fieldKey === c2.fieldKey)))}
                        aria-label="Remove"
                        className="rounded p-0.5 text-fg-subtle hover:text-danger"
                      >
                        ✕
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
            <div className="border-t border-border p-2.5">
              <button
                onClick={() => cart.length && setDrawer(true)}
                className={`w-full rounded-md bg-accent px-3 py-1.5 text-sm font-medium text-fg-on-accent hover:bg-accent-hover ${cart.length ? "" : "pointer-events-none opacity-50"}`}
              >
                Build survey →
              </button>
            </div>
          </div>

          {/* surveys sent */}
          <div className="rounded-lg border border-border bg-surface-raised shadow-sm">
            <div className="flex items-center justify-between border-b border-border px-3 py-2">
              <h2 className="text-sm font-semibold text-fg">Surveys sent</h2>
              <span className="font-mono text-2xs text-fg-subtle">{surveys.length}</span>
            </div>
            {surveys.length === 0 ? (
              <div className="px-3 py-6 text-center text-xs text-fg-subtle">No surveys sent yet.</div>
            ) : (
              <ul className="divide-y divide-border">
                {surveys.map((s) => (
                  <li key={s.id} className="px-3 py-2">
                    <div className="flex items-center gap-2">
                      <span className="min-w-0 flex-1 truncate text-sm font-medium text-fg">{s.title}</span>
                      {s.status === "responded" ? (
                        <StatusBadge tone="success">RESPONDED</StatusBadge>
                      ) : (
                        <StatusBadge tone="info" live>
                          AWAITING
                        </StatusBadge>
                      )}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1.5 text-2xs text-fg-subtle">
                      <span className="font-mono">✉ {s.recipient.name}</span>
                      <span>·</span>
                      <span>{s.items.length} questions</span>
                    </div>
                    {s.status !== "responded" && (
                      <button
                        onClick={() =>
                          respond.mutate(s.id, {
                            onSuccess: () =>
                              show({
                                message: `Response received from ${s.recipient.name} — ${s.items.length} gaps filled`,
                                kind: "success",
                              }),
                          })
                        }
                        className="mt-1.5 rounded border border-border px-2 py-0.5 text-2xs font-medium text-fg-muted hover:bg-hover hover:text-fg"
                      >
                        Simulate response
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>
      </div>

      <SurveyDrawer
        open={drawer}
        onClose={() => setDrawer(false)}
        cart={cart}
        model={model}
        contacts={contacts}
        onSend={(recipientId, title, questions) => {
          sendSurvey.mutate(
            {
              recipientId,
              title,
              items: cart.map((c2, i) => ({ entityId: c2.entityId, fieldKey: c2.fieldKey, question: questions[i] ?? "" })),
            },
            {
              onSuccess: (survey) => {
                setCart([]);
                setDrawer(false);
                show({ message: `Survey sent to ${survey.recipient.name} · ${survey.items.length} questions`, kind: "info" });
              },
            },
          );
        }}
      />
      {toastNode}
    </main>
  );
}
