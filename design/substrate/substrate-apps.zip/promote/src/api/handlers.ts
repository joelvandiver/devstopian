import { http, HttpResponse } from "msw";
import {
  SubstrateModel,
  counts,
  type Contact,
  type Field,
  type FieldStatus,
  type Model,
  type Source,
} from "../ds/model";

/* =============================================================================
   Promotion API (mocked, HITL). An in-memory model is reviewed from the freshly
   mapped seed; edits mutate it; promoting persists to localStorage('substrate-
   model') so the Download app reflects the result.
   ========================================================================== */

let model: Model = SubstrateModel.seed();

interface SurveyItem {
  entityId: string;
  fieldKey: string;
  question: string;
}
export interface Survey {
  id: number;
  recipient: Contact;
  title: string;
  items: SurveyItem[];
  status: "sent" | "responded";
}
const surveys: Survey[] = [];
let sid = 0;

// canned answers used when a survey is "responded"
const ANSWERS: Record<string, string> = {
  complianceTier: "SOC 2 Type II",
  dataResidency: "US-only",
  address: "21715 Filigree Ct, Ashburn, VA 20147",
  assetTag: "AST-RK04A1-0098",
  warrantyExpiry: "2027-03-31",
  supportContract: "ProSupport Plus · exp 2027-06",
  maintenanceVendor: "Vertiv · contract VX-2231",
};

function findField(eid: string, key: string): Field | undefined {
  return model.entities.find((e) => e.id === eid)?.fields.find((f) => f.key === key);
}

function setValue(eid: string, key: string, value: string, source: Source, status: FieldStatus) {
  const f = findField(eid, key);
  if (!f) return;
  f.value = value;
  f.status = status;
  f.source = source;
  f.confidence = source.confidence ?? 1;
}

export const handlers = [
  http.get("/api/model", () => HttpResponse.json(model)),
  http.get("/api/contacts", () => HttpResponse.json(model.contacts)),
  http.get("/api/surveys", () => HttpResponse.json(surveys)),

  // generic field edit: confirm, manual value, choose conflict candidate
  http.patch("/api/model/entities/:eid/fields/:key", async ({ params, request }) => {
    const body = (await request.json()) as {
      value?: string;
      status?: FieldStatus;
      source?: Source;
      confidence?: number;
    };
    const f = findField(String(params.eid), String(params.key));
    if (!f) return new HttpResponse(null, { status: 404 });
    if (body.value !== undefined) f.value = body.value;
    if (body.status !== undefined) f.status = body.status;
    if (body.source !== undefined) f.source = body.source;
    if (body.confidence !== undefined) f.confidence = body.confidence;
    return HttpResponse.json(model);
  }),

  http.post("/api/surveys", async ({ request }) => {
    const body = (await request.json()) as { recipientId: string; title: string; items: SurveyItem[] };
    const recipient = model.contacts.find((c) => c.id === body.recipientId);
    if (!recipient) return new HttpResponse(null, { status: 400 });
    const survey: Survey = {
      id: ++sid,
      recipient,
      title: body.title,
      items: body.items,
      status: "sent",
    };
    surveys.push(survey);
    // mark surveyed fields awaiting
    body.items.forEach((it) => {
      const f = findField(it.entityId, it.fieldKey);
      if (f) {
        f.status = "awaiting";
        f.source = { file: null, agent: "survey" };
      }
    });
    return HttpResponse.json(survey, { status: 201 });
  }),

  http.post("/api/surveys/:id/respond", ({ params }) => {
    const survey = surveys.find((s) => s.id === Number(params.id));
    if (!survey) return new HttpResponse(null, { status: 404 });
    survey.status = "responded";
    survey.items.forEach((it) => {
      const ans = ANSWERS[it.fieldKey] ?? "Provided by " + survey.recipient.name;
      setValue(it.entityId, it.fieldKey, ans, { file: null, agent: "survey", confidence: 1 }, "confirmed");
    });
    return HttpResponse.json(survey);
  }),

  http.post("/api/model/promote", () => {
    model.meta.version = "1.0.0";
    model.meta.generated = new Date().toISOString();
    SubstrateModel.save(model);
    const c = counts(model);
    const open = c.review + c.conflict + c.gap + c.awaiting;
    return HttpResponse.json({ counts: c, open });
  }),
];
