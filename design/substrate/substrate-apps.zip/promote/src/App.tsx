import { AppBar, Footer, appHref } from "./ds";
import { PromoteView } from "./features/PromoteView";

export default function App() {
  return (
    <>
      <AppBar active="promote" maxW="max-w-[1600px]" />
      <PromoteView />
      <Footer maxW="max-w-[1600px]">
        <a href={appHref("download")} className="ml-auto text-xs text-fg-subtle hover:text-fg">
          Continue to download →
        </a>
      </Footer>
    </>
  );
}
