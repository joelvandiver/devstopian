import { http, HttpResponse } from "msw";

/* =============================================================================
   Design Guide API (mocked). Even the documentation is API-driven: the token
   reference and the component gallery metadata are fetched via TanStack Query.
   Live component previews are rendered in React; the copyable markup snippet
   for each comes from GET /api/components.
   ========================================================================== */

export interface TokenCatalog {
  grayScale: string[];
  brandScale: string[];
  semantic: { cls: string; label: string; note: string; swatchText?: string }[];
  status: { tone: "info" | "success" | "warning" | "danger"; title: string; desc: string }[];
  type: { size: string; sample: string; mono?: boolean }[];
  spacing: { step: string; px: string; w: string }[];
  radius: { name: string; px: string; cls: string }[];
  elevation: { cls: string }[];
  stats: { label: string; value: string }[];
}

const SCALE = ["50", "100", "200", "300", "400", "500", "600", "700", "800", "900", "950"];

const tokenCatalog: TokenCatalog = {
  grayScale: SCALE,
  brandScale: SCALE,
  semantic: [
    { cls: "bg-surface", label: "bg-surface", note: "page" },
    { cls: "bg-surface-raised", label: "bg-surface-raised", note: "card / header" },
    { cls: "bg-surface-sunken", label: "bg-surface-sunken", note: "inset / stripe" },
    { cls: "bg-surface-overlay", label: "bg-surface-overlay", note: "menu / tooltip" },
    { cls: "bg-accent", label: "bg-accent", note: "primary action" },
    { cls: "text-fg", label: "text-fg", note: "primary text", swatchText: "Aa" },
    { cls: "text-fg-muted", label: "text-fg-muted", note: "secondary", swatchText: "Aa" },
    { cls: "text-fg-subtle", label: "text-fg-subtle", note: "tertiary", swatchText: "Aa" },
  ],
  status: [
    { tone: "info", title: "Info", desc: "Scheduled maintenance" },
    { tone: "success", title: "Success", desc: "Rack operational" },
    { tone: "warning", title: "Warning", desc: "Cooling threshold near" },
    { tone: "danger", title: "Danger", desc: "Node offline" },
  ],
  type: [
    { size: "4xl", sample: "Rack RK-04" },
    { size: "3xl", sample: "Throughput 41.2 Gb/s" },
    { size: "2xl", sample: "Cooling loop B" },
    { size: "xl", sample: "Network topology" },
    { size: "lg", sample: "Power draw summary" },
    { size: "base", sample: "Default body — 14px, the workhorse size for tables and forms." },
    { size: "sm", sample: "Secondary — 13px metadata and helper text." },
    { size: "xs", sample: "12px — labels, captions." },
    { size: "2xs", sample: "11px · overline / tags", mono: true },
  ],
  spacing: [
    { step: "1", px: "4px", w: "w-1" },
    { step: "2", px: "8px", w: "w-2" },
    { step: "3", px: "12px", w: "w-3" },
    { step: "4", px: "16px", w: "w-4" },
    { step: "6", px: "24px", w: "w-6" },
    { step: "8", px: "32px", w: "w-8" },
  ],
  radius: [
    { name: "xs", px: "2", cls: "rounded-xs" },
    { name: "sm", px: "3", cls: "rounded-sm" },
    { name: "md", px: "5", cls: "rounded-md" },
    { name: "lg", px: "8", cls: "rounded-lg" },
    { name: "xl", px: "12", cls: "rounded-xl" },
  ],
  elevation: [{ cls: "shadow-xs" }, { cls: "shadow-sm" }, { cls: "shadow-md" }, { cls: "shadow-lg" }],
  stats: [
    { label: "Primitives", value: "34" },
    { label: "Semantic tokens", value: "38" },
    { label: "Components", value: "12" },
    { label: "Build step", value: "Vite" },
  ],
};

export interface ComponentEntry {
  id: string;
  title: string;
  description: string;
  snippet: string;
}

const components: ComponentEntry[] = [
  {
    id: "buttons",
    title: "Buttons",
    description: "Accent, secondary, ghost, danger, small and disabled — composed from utilities.",
    snippet: `<button class="inline-flex items-center gap-1.5 rounded-md bg-accent px-3 py-1.5 text-sm font-medium text-fg-on-accent hover:bg-accent-hover">Provision rack</button>
<button class="inline-flex items-center gap-1.5 rounded-md border border-border bg-surface px-3 py-1.5 text-sm font-medium text-fg hover:bg-hover">Secondary</button>
<button class="inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium text-fg-muted hover:bg-hover hover:text-fg">Ghost</button>`,
  },
  {
    id: "badges",
    title: "Badges & status",
    description: "Status chips with live pips for info · success · warning · danger plus neutral tags.",
    snippet: `<span class="inline-flex items-center gap-1 rounded-sm border border-success-border bg-success-bg px-1.5 py-0.5 text-2xs font-medium text-success"><span class="size-1.5 rounded-full bg-success"></span>OPERATIONAL</span>`,
  },
  {
    id: "forms",
    title: "Form controls",
    description: "Compact inputs, selects, number fields, checkboxes and radios with a visible focus ring.",
    snippet: `<label class="block"><span class="mb-1 block text-xs font-medium text-fg-muted">Rack label</span>
  <input type="text" value="RK-04-B12" class="w-full rounded-md border border-border bg-surface px-2.5 py-1.5 text-sm text-fg focus:border-accent focus:outline-none focus:ring-2 focus:ring-ring/40"></label>`,
  },
  {
    id: "meta",
    title: "Inline metadata",
    description: "Dense definition lists for telemetry: uptime, throughput, inlet temp, power, PUE.",
    snippet: `<dl class="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
  <div class="flex items-center gap-1.5"><dt class="text-fg-subtle">Uptime</dt><dd class="font-mono font-medium text-success tabular-nums">99.992%</dd></div>
</dl>`,
  },
  {
    id: "cards",
    title: "Cards",
    description: "Status-headed cards with a metric and a utilization bar.",
    snippet: `<div class="rounded-lg border border-border bg-surface-raised shadow-sm">
  <div class="flex items-center justify-between border-b border-border px-3 py-2"><h4 class="text-sm font-semibold text-fg">Rack RK-04</h4></div>
  <div class="px-3 py-2.5">…</div>
</div>`,
  },
  {
    id: "banners",
    title: "Banners",
    description: "Announcement bar plus warning and danger alert banners built from the status triads.",
    snippet: `<div class="flex items-center gap-3 rounded-md bg-accent px-3 py-2 text-fg-on-accent">
  <span class="rounded-sm bg-white/20 px-1.5 py-0.5 text-2xs font-semibold uppercase tracking-wide">New</span>
  <p class="text-sm">Region <span class="font-semibold">ap-south-1</span> is now live.</p>
</div>`,
  },
];

export const handlers = [
  http.get("/api/tokens", () => HttpResponse.json(tokenCatalog)),
  http.get("/api/components", () => HttpResponse.json(components)),
];
