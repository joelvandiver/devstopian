import { useTokens } from "./api";

export function Hero() {
  const { data } = useTokens();
  const stats = data?.stats ?? [];
  return (
    <section className="border-b border-border bg-surface-sunken">
      <div className="mx-auto max-w-[1480px] px-4 py-10 md:py-14">
        <div className="max-w-3xl">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-accent-border bg-accent-muted px-2.5 py-1 text-2xs font-medium text-accent">
            <span className="size-1.5 rounded-full bg-accent" />
            DATA CENTER INFRASTRUCTURE · DESIGN SYSTEM
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-fg">Substrate</h1>
          <p className="mt-3 text-lg text-fg-muted text-pretty">
            A dense, token-driven design system for data center control planes — rack inventory,
            throughput dashboards, cooling telemetry and network topology. Built on{" "}
            <span className="font-medium text-fg">Tailwind CSS v4</span> with a primitive → semantic
            token model, runtime light/dark theming, and predictable utility markup. Now shipped as
            five React + TypeScript apps backed by MSW &amp; TanStack Query.
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <a href="#components" className="inline-flex items-center gap-1.5 rounded-md bg-accent px-3.5 py-2 text-sm font-medium text-fg-on-accent hover:bg-accent-hover">Browse components</a>
            <a href="#tokens" className="inline-flex items-center gap-1.5 rounded-md border border-border bg-surface px-3.5 py-2 text-sm font-medium text-fg hover:bg-hover">Design tokens</a>
          </div>
          <dl className="mt-8 grid max-w-2xl grid-cols-2 gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-4">
            {stats.map((s) => (
              <div key={s.label} className="bg-surface px-3 py-2.5">
                <dt className="text-2xs font-mono uppercase tracking-wide text-fg-subtle">{s.label}</dt>
                <dd className="mt-0.5 text-xl font-semibold tabular-nums text-fg">{s.value}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  );
}
