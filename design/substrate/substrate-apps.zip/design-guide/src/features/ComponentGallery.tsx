import type { ReactNode } from "react";
import { useComponents } from "./api";
import { useCopy, Button, StatusBadge, ProgressBar } from "../ds";

/* Live previews are real React; the copyable markup snippet comes from the API.
   Keyed by the component id returned from GET /api/components. */
const PREVIEWS: Record<string, ReactNode> = {
  buttons: (
    <div className="flex flex-wrap items-center gap-2">
      <Button variant="accent">Provision rack</Button>
      <Button variant="secondary">Secondary</Button>
      <Button variant="ghost">Ghost</Button>
      <Button variant="danger">Decommission</Button>
      <Button variant="accent" size="sm">Small</Button>
      <Button variant="accent" disabled>Disabled</Button>
    </div>
  ),
  badges: (
    <div className="flex flex-wrap items-center gap-2">
      <StatusBadge tone="success">OPERATIONAL</StatusBadge>
      <StatusBadge tone="warning">DEGRADED</StatusBadge>
      <StatusBadge tone="danger">OFFLINE</StatusBadge>
      <StatusBadge tone="info">MAINTENANCE</StatusBadge>
      <span className="inline-flex items-center rounded-sm border border-border bg-surface-sunken px-1.5 py-0.5 font-mono text-2xs text-fg-muted">us-east-2b</span>
      <span className="inline-flex items-center rounded-full bg-accent-muted px-2 py-0.5 text-2xs font-medium text-accent">12 nodes</span>
    </div>
  ),
  forms: (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      <label className="block">
        <span className="mb-1 block text-xs font-medium text-fg-muted">Rack label</span>
        <input type="text" defaultValue="RK-04-B12" className="w-full rounded-md border border-border bg-surface px-2.5 py-1.5 text-sm text-fg focus:border-accent focus:outline-none focus:ring-2 focus:ring-ring/40" />
      </label>
      <label className="block">
        <span className="mb-1 block text-xs font-medium text-fg-muted">Region</span>
        <select className="w-full rounded-md border border-border bg-surface px-2.5 py-1.5 text-sm text-fg focus:border-accent focus:outline-none focus:ring-2 focus:ring-ring/40">
          <option>us-east-2</option><option>eu-west-1</option><option>ap-south-1</option>
        </select>
      </label>
      <label className="block">
        <span className="mb-1 block text-xs font-medium text-fg-muted">Power cap (kW)</span>
        <input type="number" defaultValue="8.5" step="0.1" className="w-full rounded-md border border-border bg-surface px-2.5 py-1.5 text-sm tabular-nums text-fg focus:border-accent focus:outline-none focus:ring-2 focus:ring-ring/40" />
      </label>
      <label className="flex items-center gap-2 text-sm text-fg">
        <input type="checkbox" defaultChecked className="size-4 rounded border-border text-accent focus:ring-ring/40" /> Redundant PSU
      </label>
      <label className="flex items-center gap-2 text-sm text-fg">
        <input type="radio" name="cool" defaultChecked className="size-4 border-border text-accent focus:ring-ring/40" /> Liquid cooling
      </label>
      <label className="flex items-center gap-2 text-sm text-fg">
        <input type="radio" name="cool" className="size-4 border-border text-accent focus:ring-ring/40" /> Air cooling
      </label>
    </div>
  ),
  meta: (
    <dl className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
      <div className="flex items-center gap-1.5"><dt className="text-fg-subtle">Uptime</dt><dd className="font-mono font-medium text-success tabular-nums">99.992%</dd></div>
      <div className="flex items-center gap-1.5"><dt className="text-fg-subtle">Throughput</dt><dd className="font-mono font-medium text-fg tabular-nums">41.2 Gb/s</dd></div>
      <div className="flex items-center gap-1.5"><dt className="text-fg-subtle">Inlet temp</dt><dd className="font-mono font-medium text-warning tabular-nums">27.4 °C</dd></div>
      <div className="flex items-center gap-1.5"><dt className="text-fg-subtle">Power</dt><dd className="font-mono font-medium text-fg tabular-nums">7.8 / 8.5 kW</dd></div>
      <div className="flex items-center gap-1.5"><dt className="text-fg-subtle">PUE</dt><dd className="font-mono font-medium text-fg tabular-nums">1.18</dd></div>
    </dl>
  ),
  cards: (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {[
        { title: "Rack RK-04", tone: "success" as const, badge: "OK", sub: "42U · us-east-2b · row C", big: "38", unit: "/ 42U used", w: "w-[90%]", fill: "bg-accent" },
        { title: "Cooling loop B", tone: "warning" as const, badge: "WARM", sub: "Chilled water · 2 CRAH units", big: "27.4", unit: "°C inlet", w: "w-[78%]", fill: "bg-warning" },
        { title: "Spine sw-core-01", tone: "danger" as const, badge: "DOWN", sub: "100GbE · port 14 flapping", big: "0", unit: "Gb/s", w: "w-[4%]", fill: "bg-danger" },
      ].map((c) => (
        <div key={c.title} className="rounded-lg border border-border bg-surface-raised shadow-sm">
          <div className="flex items-center justify-between border-b border-border px-3 py-2">
            <h4 className="text-sm font-semibold text-fg">{c.title}</h4>
            <StatusBadge tone={c.tone}>{c.badge}</StatusBadge>
          </div>
          <div className="px-3 py-2.5">
            <p className="text-xs text-fg-muted">{c.sub}</p>
            <div className="mt-2 flex items-baseline gap-1">
              <span className="text-2xl font-semibold tabular-nums text-fg">{c.big}</span>
              <span className="text-xs text-fg-subtle">{c.unit}</span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-surface-inset">
              <div className={`h-full rounded-full ${c.fill} ${c.w}`} />
            </div>
          </div>
        </div>
      ))}
    </div>
  ),
  banners: (
    <div className="space-y-3">
      <div className="flex items-center gap-3 rounded-md bg-accent px-3 py-2 text-fg-on-accent">
        <span className="rounded-sm bg-white/20 px-1.5 py-0.5 text-2xs font-semibold uppercase tracking-wide">New</span>
        <p className="text-sm">Region <span className="font-semibold">ap-south-1</span> is now live — 3 availability zones, 1,200 racks.</p>
        <a href="#" className="ml-auto shrink-0 text-sm font-medium underline underline-offset-2 hover:opacity-90">Details</a>
      </div>
      <div className="flex items-start gap-3 rounded-md border border-warning-border bg-warning-bg px-3 py-2.5 text-warning">
        <span className="mt-0.5 grid size-4 shrink-0 place-items-center rounded-full border border-warning text-2xs font-bold">!</span>
        <div className="min-w-0">
          <p className="text-sm font-semibold">Cooling threshold approaching in row C</p>
          <p className="text-xs text-warning/80">Inlet temperature 27.4 °C, 2 °C below shutdown.</p>
        </div>
      </div>
      <div className="flex items-start gap-3 rounded-md border border-danger-border bg-danger-bg px-3 py-2.5 text-danger">
        <span className="mt-0.5 grid size-4 shrink-0 place-items-center rounded-full border border-danger text-2xs font-bold">!</span>
        <div className="min-w-0">
          <p className="text-sm font-semibold">Spine switch sw-core-01 unreachable</p>
          <p className="text-xs text-danger/80">Failover to sw-core-02 active. 14 racks on degraded path.</p>
        </div>
      </div>
    </div>
  ),
};

function GalleryBlock({
  title,
  description,
  snippet,
  preview,
}: {
  title: string;
  description: string;
  snippet: string;
  preview: ReactNode;
}) {
  const { copied, copy } = useCopy();
  return (
    <div className="mb-8 scroll-mt-16">
      <h3 className="mb-1 text-md font-semibold text-fg">{title}</h3>
      <p className="mb-2 text-sm text-fg-subtle">{description}</p>
      <div className="overflow-hidden rounded-lg border border-border">
        <div className="bg-surface p-4">{preview}</div>
        <div className="flex items-center justify-between border-t border-border bg-surface-sunken px-3 py-1.5">
          <span className="font-mono text-2xs uppercase tracking-wide text-fg-subtle">markup</span>
          <button
            onClick={() => copy(snippet)}
            className="rounded px-2 py-0.5 text-2xs font-medium text-fg-muted hover:bg-hover hover:text-fg"
          >
            {copied ? "Copied" : "Copy"}
          </button>
        </div>
        <pre className="overflow-x-auto bg-surface-inset px-3 py-2 text-2xs leading-relaxed">
          <code className="font-mono text-fg-muted">{snippet}</code>
        </pre>
      </div>
    </div>
  );
}

export function ComponentGallery() {
  const { data, isLoading, isError } = useComponents();

  return (
    <section id="components" className="mt-12 scroll-mt-16">
      <div className="mb-4 border-b border-border pb-3">
        <h2 className="text-2xl font-bold tracking-tight text-fg">Components</h2>
        <p className="mt-1 max-w-2xl text-base text-fg-muted text-pretty">
          Every component is plain semantic markup composed from utilities. Each block mirrors its
          live markup below — hit <span className="font-medium text-fg">Copy</span> to lift it.
        </p>
      </div>
      {isLoading && <p className="text-sm text-fg-muted">Loading components…</p>}
      {isError && <p className="text-sm text-danger">Failed to load components.</p>}
      {data?.map((c) => (
        <GalleryBlock
          key={c.id}
          title={c.title}
          description={c.description}
          snippet={c.snippet}
          preview={PREVIEWS[c.id] ?? <ProgressBar value={50} />}
        />
      ))}
    </section>
  );
}
