import { useTokens } from "./api";

/* Full literal class names so Tailwind's scanner emits every swatch. The API
   supplies the labels/steps; these arrays supply the matching utilities. */
const GRAY_BG = [
  "bg-gray-50", "bg-gray-100", "bg-gray-200", "bg-gray-300", "bg-gray-400", "bg-gray-500",
  "bg-gray-600", "bg-gray-700", "bg-gray-800", "bg-gray-900", "bg-gray-950",
];
const BRAND_BG = [
  "bg-brand-50", "bg-brand-100", "bg-brand-200", "bg-brand-300", "bg-brand-400", "bg-brand-500",
  "bg-brand-600", "bg-brand-700", "bg-brand-800", "bg-brand-900", "bg-brand-950",
];
const TYPE_CLS: Record<string, string> = {
  "4xl": "text-4xl font-bold text-fg",
  "3xl": "text-3xl font-semibold text-fg",
  "2xl": "text-2xl font-semibold text-fg",
  xl: "text-xl font-medium text-fg",
  lg: "text-lg text-fg",
  base: "text-base text-fg",
  sm: "text-sm text-fg-muted",
  xs: "text-xs text-fg-muted",
  "2xs": "text-2xs font-mono uppercase tracking-wide text-fg-subtle",
};
const STATUS_CARD: Record<string, string> = {
  info: "border-info-border bg-info-bg",
  success: "border-success-border bg-success-bg",
  warning: "border-warning-border bg-warning-bg",
  danger: "border-danger-border bg-danger-bg",
};
const STATUS_TEXT: Record<string, string> = {
  info: "text-info",
  success: "text-success",
  warning: "text-warning",
  danger: "text-danger",
};
// full literal opacity variants (Tailwind can't see concatenated names)
const STATUS_TEXT_80: Record<string, string> = {
  info: "text-info/80",
  success: "text-success/80",
  warning: "text-warning/80",
  danger: "text-danger/80",
};
const STATUS_TEXT_70: Record<string, string> = {
  info: "text-info/70",
  success: "text-success/70",
  warning: "text-warning/70",
  danger: "text-danger/70",
};

function Swatches({ steps, classes }: { steps: string[]; classes: string[] }) {
  return (
    <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-6 lg:grid-cols-11">
      {steps.map((s, i) => (
        <div key={s}>
          <div className={`h-12 rounded border border-border ${classes[i]}`} />
          <p className="mt-1 font-mono text-2xs text-fg-subtle">{s}</p>
        </div>
      ))}
    </div>
  );
}

export function TokenReference() {
  const { data, isLoading, isError } = useTokens();

  if (isLoading)
    return <p className="text-sm text-fg-muted">Loading tokens…</p>;
  if (isError || !data)
    return <p className="text-sm text-danger">Failed to load token catalog.</p>;

  return (
    <section id="tokens" className="scroll-mt-16">
      <div className="mb-4 border-b border-border pb-3">
        <h2 className="text-2xl font-bold tracking-tight text-fg">Design tokens</h2>
        <p className="mt-1 max-w-2xl text-base text-fg-muted text-pretty">
          Declared with Tailwind v4's <code className="rounded bg-surface-inset px-1 py-0.5 font-mono text-xs text-accent">@theme</code> directive.
          Primitives generate static utilities; semantic tokens live in <code className="rounded bg-surface-inset px-1 py-0.5 font-mono text-xs text-accent">:root</code> /
          <code className="rounded bg-surface-inset px-1 py-0.5 font-mono text-xs text-accent"> .dark</code>. Toggle the theme (top-right) to watch them swap.
        </p>
      </div>

      {/* Color primitives */}
      <div id="color-primitives" className="scroll-mt-16">
        <h3 className="mb-1 text-md font-semibold text-fg">Color primitives</h3>
        <p className="mb-3 text-sm text-fg-subtle">Fixed brand &amp; neutral scales.</p>
        <p className="mb-1.5 text-2xs font-mono uppercase tracking-wide text-fg-subtle">Neutral (cool gray)</p>
        <div className="mb-4">
          <Swatches steps={data.grayScale} classes={GRAY_BG} />
        </div>
        <p className="mb-1.5 text-2xs font-mono uppercase tracking-wide text-fg-subtle">Brand (cyan · uptime)</p>
        <Swatches steps={data.brandScale} classes={BRAND_BG} />
      </div>

      {/* Semantic colors */}
      <div id="color-semantic" className="mt-8 scroll-mt-16">
        <h3 className="mb-1 text-md font-semibold text-fg">Semantic colors</h3>
        <p className="mb-3 text-sm text-fg-subtle">Theme-aware. Components reference <em>only</em> these — never primitives.</p>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
          {data.semantic.map((s) => (
            <div key={s.cls} className="overflow-hidden rounded-lg border border-border">
              <div className={`grid h-12 place-items-center bg-surface`}>
                {s.swatchText ? (
                  <span className={`${s.cls} text-sm`}>{s.swatchText}</span>
                ) : (
                  <div className={`h-full w-full ${s.cls}`} />
                )}
              </div>
              <div className="border-t border-border px-2 py-1.5">
                <p className="font-mono text-2xs text-fg">{s.label}</p>
                <p className="font-mono text-2xs text-fg-subtle">{s.note}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Status colors */}
      <div id="status" className="mt-8 scroll-mt-16">
        <h3 className="mb-1 text-md font-semibold text-fg">Status colors</h3>
        <p className="mb-3 text-sm text-fg-subtle">Each ships an fg / bg / border triad with light- and dark-tuned values.</p>
        <div className="grid grid-cols-2 gap-2 lg:grid-cols-4">
          {data.status.map((s) => (
            <div key={s.tone} className={`rounded-lg border px-3 py-2.5 ${STATUS_CARD[s.tone]}`}>
              <p className={`text-sm font-semibold ${STATUS_TEXT[s.tone]}`}>{s.title}</p>
              <p className={`mt-0.5 text-xs ${STATUS_TEXT_80[s.tone]}`}>{s.desc}</p>
              <p className={`mt-2 font-mono text-2xs ${STATUS_TEXT_70[s.tone]}`}>text-{s.tone} · bg-{s.tone}-bg</p>
            </div>
          ))}
        </div>
      </div>

      {/* Typography */}
      <div id="type" className="mt-8 scroll-mt-16">
        <h3 className="mb-1 text-md font-semibold text-fg">Typography</h3>
        <p className="mb-3 text-sm text-fg-subtle">Roboto for UI, Roboto Mono for identifiers &amp; metrics.</p>
        <div className="divide-y divide-border overflow-hidden rounded-lg border border-border">
          {data.type.map((t) => (
            <div key={t.size} className="flex items-baseline gap-4 px-3 py-2">
              <code className="w-16 shrink-0 font-mono text-2xs text-fg-subtle">{t.size}</code>
              <span className={TYPE_CLS[t.size]}>{t.sample}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Spacing / radius / elevation */}
      <div id="scale" className="mt-8 grid scroll-mt-16 gap-4 md:grid-cols-3">
        <div>
          <h3 className="mb-1 text-md font-semibold text-fg">Spacing</h3>
          <p className="mb-3 text-sm text-fg-subtle">0.25rem base. Default tight.</p>
          <div className="space-y-1.5">
            {data.spacing.map((s) => (
              <div key={s.step} className="flex items-center gap-2">
                <code className="w-8 font-mono text-2xs text-fg-subtle">{s.step}</code>
                <div className={`h-3 ${s.w} bg-accent`} />
                <span className="text-xs text-fg-muted">{s.px}</span>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h3 className="mb-1 text-md font-semibold text-fg">Radius</h3>
          <p className="mb-3 text-sm text-fg-subtle">Tight corners suit data-dense surfaces.</p>
          <div className="flex flex-wrap gap-2">
            {data.radius.map((r) => (
              <div key={r.name} className="text-center">
                <div className={`size-12 border border-border bg-surface-inset ${r.cls}`} />
                <p className="mt-1 font-mono text-2xs text-fg-subtle">{r.name} {r.px}</p>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h3 className="mb-1 text-md font-semibold text-fg">Elevation</h3>
          <p className="mb-3 text-sm text-fg-subtle">Subtle — dense UIs lean on borders.</p>
          <div className="grid grid-cols-2 gap-3">
            {data.elevation.map((e) => (
              <div key={e.cls} className={`rounded-lg bg-surface-raised p-3 ${e.cls}`}>
                <p className="font-mono text-2xs text-fg-subtle">{e.cls}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
