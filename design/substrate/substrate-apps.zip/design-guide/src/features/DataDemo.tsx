import { useState } from "react";
import { DataTable, Tree, type Column, type Density, type TreeNode } from "../ds";

interface Rack {
  rack: string;
  hall: string;
  status: "OK" | "Warm" | "Down";
  gbps: number;
  power: number;
  uUsed: number;
}

const RACKS: Rack[] = [
  { rack: "RK-04", hall: "Hall A", status: "OK", gbps: 41.2, power: 7.8, uUsed: 38 },
  { rack: "RK-05", hall: "Hall A", status: "Warm", gbps: 38.7, power: 8.1, uUsed: 40 },
  { rack: "RK-06", hall: "Hall B", status: "Down", gbps: 0.0, power: 0.4, uUsed: 12 },
  { rack: "RK-07", hall: "Hall B", status: "OK", gbps: 39.9, power: 7.2, uUsed: 35 },
  { rack: "RK-08", hall: "Hall C", status: "OK", gbps: 44.1, power: 8.3, uUsed: 41 },
];

const STATUS_DOT: Record<Rack["status"], string> = {
  OK: "text-success",
  Warm: "text-warning",
  Down: "text-danger",
};

const TREE: TreeNode[] = [
  {
    id: "us-east-2",
    label: "region us-east-2",
    children: [
      {
        id: "iad-7",
        label: "dc iad-7",
        children: [
          { id: "hall-a", label: "Hall A · 240 racks", children: [
            { id: "rk-04", label: "RK-04 · 38/42U" },
            { id: "rk-05", label: "RK-05 · 40/42U" },
          ] },
          { id: "hall-b", label: "Hall B · 240 racks" },
        ],
      },
      { id: "iad-9", label: "dc iad-9", children: [{ id: "hall-x", label: "Hall X · 180 racks" }] },
    ],
  },
];

export function DataDemo() {
  const [density, setDensity] = useState<Density>("compact");

  const columns: Column<Rack>[] = [
    { key: "rack", header: "Rack", sortable: true, sticky: true, sortValue: (r) => r.rack, render: (r) => <span className="font-mono text-fg">{r.rack}</span> },
    { key: "hall", header: "Hall", sortable: true, sortValue: (r) => r.hall, render: (r) => r.hall },
    { key: "status", header: "Status", sortable: true, sortValue: (r) => r.status, render: (r) => (
      <span><span className={STATUS_DOT[r.status]}>●</span> {r.status}</span>
    ) },
    { key: "gbps", header: "Gb/s", align: "right", sortable: true, sortType: "number", sortValue: (r) => r.gbps, render: (r) => <span className="font-mono tabular-nums text-fg">{r.gbps.toFixed(1)}</span> },
    { key: "power", header: "kW", align: "right", sortable: true, sortType: "number", sortValue: (r) => r.power, render: (r) => <span className="font-mono tabular-nums text-fg">{r.power.toFixed(1)}</span> },
    { key: "uUsed", header: "U used", align: "right", sortable: true, sortType: "number", sortValue: (r) => r.uUsed, render: (r) => <span className="font-mono tabular-nums text-fg">{r.uUsed}</span> },
  ];

  return (
    <section id="data" className="mt-12 scroll-mt-16">
      <div className="mb-4 border-b border-border pb-3">
        <h2 className="text-2xl font-bold tracking-tight text-fg">Table &amp; tree</h2>
        <p className="mt-1 max-w-2xl text-base text-fg-muted text-pretty">
          The condensed <code className="font-mono text-xs text-accent">DataTable</code> (sortable, sticky,
          density variants) and the interactive <code className="font-mono text-xs text-accent">Tree</code>
          (keyboard nav + drag-and-drop) — the same shared components every app uses.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <div className="mb-2 flex items-center gap-2">
            <h3 className="text-md font-semibold text-fg">Condensed table</h3>
            <div className="ml-auto inline-flex items-center gap-0.5 rounded-md border border-border bg-surface p-0.5 text-xs">
              {(["compact", "default", "comfortable"] as Density[]).map((d) => (
                <button
                  key={d}
                  onClick={() => setDensity(d)}
                  aria-pressed={density === d}
                  className={`rounded px-2 py-1 font-medium ${density === d ? "bg-accent text-fg-on-accent" : "text-fg-muted hover:text-fg"}`}
                >
                  {d}
                </button>
              ))}
            </div>
          </div>
          <DataTable columns={columns} rows={RACKS} density={density} getRowKey={(r) => r.rack} />
          <p className="mt-2 text-2xs text-fg-subtle">Click a header to sort. First column &amp; header stay pinned on scroll.</p>
        </div>

        <div>
          <h3 className="mb-2 text-md font-semibold text-fg">Infrastructure tree</h3>
          <div className="rounded-lg border border-border bg-surface-raised p-2">
            <Tree data={TREE} />
          </div>
          <p className="mt-2 text-2xs text-fg-subtle">Arrow keys navigate; drag the ⠿ handle to re-nest or reorder.</p>
        </div>
      </div>
    </section>
  );
}
