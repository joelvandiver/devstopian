import { useQuery } from "@tanstack/react-query";
import type { ComponentEntry, TokenCatalog } from "../api/handlers";

async function getJSON<T>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${res.status} ${url}`);
  return res.json() as Promise<T>;
}

export function useTokens() {
  return useQuery({ queryKey: ["tokens"], queryFn: () => getJSON<TokenCatalog>("/api/tokens") });
}

export function useComponents() {
  return useQuery({
    queryKey: ["components"],
    queryFn: () => getJSON<ComponentEntry[]>("/api/components"),
  });
}
