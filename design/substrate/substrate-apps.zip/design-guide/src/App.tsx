import { AppBar, Footer } from "./ds";
import { Hero } from "./features/Hero";
import { TokenReference } from "./features/TokenReference";
import { ComponentGallery } from "./features/ComponentGallery";
import { DataDemo } from "./features/DataDemo";

export default function App() {
  return (
    <>
      <AppBar
        active="design-guide"
        extra={
          <span className="hidden items-center gap-1.5 rounded-md border border-border bg-surface px-2 py-1 text-2xs font-mono text-fg-subtle md:inline-flex">
            <span className="size-1.5 rounded-full bg-success" />
            tailwind v4
          </span>
        }
      />
      <Hero />
      <div className="mx-auto max-w-[1480px] px-4 py-8">
        <main className="min-w-0">
          <TokenReference />
          <ComponentGallery />
          <DataDemo />
        </main>
      </div>
      <Footer>
        <p className="ml-auto text-xs text-fg-subtle">
          Tailwind CSS v4 · tokens in <code className="font-mono">ds/tokens.css</code>
        </p>
      </Footer>
    </>
  );
}
